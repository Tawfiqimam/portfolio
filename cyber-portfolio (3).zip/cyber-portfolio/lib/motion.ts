import type { Transition } from "framer-motion";

/**
 * Shared easing and timing. Declared once and typed as `Transition` so the
 * cubic-bezier tuple is contextually typed wherever it is reused — the same
 * curve as `--ease-out-expo` in globals.css, so CSS and JS motion match.
 */
export const EASE_OUT_EXPO: [number, number, number, number] = [0.16, 1, 0.3, 1];

/** Entrance: generous, confident. */
export const enter: Transition = {
  duration: 0.6,
  ease: EASE_OUT_EXPO,
};

/** Exit: faster than enter, so dismissal never feels sluggish. */
export const exit: Transition = {
  duration: 0.28,
  ease: EASE_OUT_EXPO,
};

/** Hero choreography — one shared curve, staggered by delay. */
export const hero = (delay: number): Transition => ({
  duration: 0.75,
  delay,
  ease: EASE_OUT_EXPO,
});
