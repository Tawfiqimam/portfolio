/**
 * Minimal class-name joiner. Falsy values are dropped so conditional
 * classes can be written inline without a dependency on clsx.
 */
export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

/** Clamp a number into an inclusive range. */
export function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}
