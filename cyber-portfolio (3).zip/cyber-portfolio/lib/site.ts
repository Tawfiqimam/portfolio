/**
 * ============================================================================
 *  SITE CONTENT — SINGLE SOURCE OF TRUTH
 * ============================================================================
 *  Everything a visitor reads lives here. Edit this file to change the site;
 *  no component needs touching for a content change.
 *
 *  Values marked  // TODO  still need your input before going public.
 * ============================================================================
 */

export const site = {
  name: "Tawfiq Imam",
  handle: "t4wf1q",
  role: "Security Researcher",
  roles: ["Security Researcher", "Bug Bounty Hunter", "Penetration Tester"],
  tagline: "Identify. Exploit. Secure.",
  headline: ["Breaking Systems.", "Securing Reality."],
  // TODO: set this to your real domain once deployed (no trailing slash).
  // Open Graph tags, the canonical URL and the sitemap all read from it.
  url: "https://example.com",
  email: "t4wf1qx@gmail.com",
  /* Deliberately city-level. A public portfolio is a recon target: a street
     address on it gives away more than it gains. */
  location: "Dhaka, Bangladesh",
  availability: "Open to security roles & penetration testing engagements",
  resumeUrl: "/resume.pdf", // TODO: drop your CV at public/resume.pdf
  /* Portrait. A transparent PNG cutout is supported — the hero draws a
     designed backdrop behind it. Point this at .png if you use one. */
  profileImage: "/profile.jpg",
  description:
    "Tawfiq Imam — independent security researcher and bug bounty hunter from Dhaka, specialising in web, API, mobile and network security. Hall of Fame recognitions from PayPal, Decathlon, TeamViewer and Stripe.",
} as const;

export type SocialLink = {
  label: string;
  href: string;
  icon: "github" | "linkedin" | "twitter" | "mail" | "globe";
  handle: string;
};

export const socials: SocialLink[] = [
  { label: "GitHub", href: "https://github.com/Tawfiqimam", icon: "github", handle: "@Tawfiqimam" },
  { label: "LinkedIn", href: "https://linkedin.com/in/tawfiqimam", icon: "linkedin", handle: "/in/tawfiqimam" },
  { label: "X", href: "https://x.com/tawfiqiimam", icon: "twitter", handle: "@tawfiqiimam" },
  { label: "Email", href: `mailto:${site.email}`, icon: "mail", handle: site.email },
];

/* -------------------------------------------------------------------------- */
/*  NAVIGATION                                                                */
/* -------------------------------------------------------------------------- */

export const navItems = [
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "research", label: "Research" },
  { id: "projects", label: "Projects" },
  { id: "education", label: "Education" },
  { id: "experience", label: "Experience" },
  { id: "arsenal", label: "Arsenal" },
  { id: "contact", label: "Contact" },
] as const;

/* -------------------------------------------------------------------------- */
/*  HERO TERMINAL SCRIPT                                                      */
/* -------------------------------------------------------------------------- */

export type TerminalLine =
  | { type: "command"; text: string }
  | { type: "output"; text: string }
  | { type: "success"; text: string };

export const heroTerminal: TerminalLine[] = [
  { type: "command", text: "whoami" },
  { type: "output", text: "Security Researcher" },
  { type: "command", text: "mission" },
  { type: "success", text: "Identify. Exploit. Secure." },
];

/* -------------------------------------------------------------------------- */
/*  ABOUT                                                                     */
/* -------------------------------------------------------------------------- */

export const about = {
  paragraphs: [
    "I'm an independent security researcher and bug bounty hunter with over two years in offensive security, working across web, mobile, API and network targets. I'm a member of YesWeHack and also report through HackerOne and Bugcrowd.",
    "My approach is manual first. Automation tells me where to look — I build my own tooling for that — but the findings that matter tend to come from reading an application's logic until the assumption it depends on becomes obvious. Scanners do not find authentication-flow flaws; patience does.",
    "Over 300 reports submitted, 100+ Hall of Fame recognitions and 50+ findings rated Critical so far, including work at PayPal, Decathlon, TeamViewer and Stripe — among them account-takeover vulnerabilities scoring CVSS 9.4. Alongside the research I'm completing a B.Sc. in Computer Science & Engineering at Southeast University in Dhaka.",
  ],
  // TODO: verify each of these against your own records before publishing.
  stats: [
    { label: "Reports submitted", value: "300+" },
    { label: "Hall of Fame recognitions", value: "100+" },
    { label: "Critical severity findings", value: "50+" },
    { label: "Years in security", value: "2+" },
  ],
  facts: [
    { key: "location", value: site.location },
    { key: "focus", value: "Web · API · Mobile · Network" },
    { key: "platforms", value: "YesWeHack · HackerOne · Bugcrowd" },
    { key: "status", value: "Available for engagements" },
  ],
} as const;

/* -------------------------------------------------------------------------- */
/*  SKILLS                                                                    */
/* -------------------------------------------------------------------------- */

export type Skill = {
  name: string;
  /** 0–100. Drives the animated meter width and the aria-valuenow. */
  level: number;
  note: string;
};

export type SkillGroup = {
  id: string;
  title: string;
  icon: "crosshair" | "globe" | "network" | "search" | "users" | "terminal";
  blurb: string;
  skills: Skill[];
};

export const skillGroups: SkillGroup[] = [
  {
    id: "research",
    title: "Vulnerability Research",
    icon: "crosshair",
    blurb: "Finding it, proving it, and writing it so it gets fixed.",
    skills: [
      { name: "Manual Vulnerability Discovery", level: 95, note: "Hands-on testing, no scanner dependency" },
      { name: "Vulnerability Assessment", level: 95, note: "Triage, scoring, impact analysis" },
      { name: "Validation & Exploitation", level: 90, note: "Proving real impact, not just presence" },
      { name: "Responsible Disclosure", level: 95, note: "Coordinated reporting end to end" },
    ],
  },
  {
    id: "web",
    title: "Web & API Security",
    icon: "globe",
    blurb: "Where most of my findings come from.",
    skills: [
      { name: "Web Application Security", level: 95, note: "Full-scope application testing" },
      { name: "OWASP Top 10 Testing", level: 95, note: "Complete coverage, manually verified" },
      { name: "API Security Testing", level: 90, note: "Auth flows, IDOR, rate limiting" },
      { name: "Authentication & Authorization", level: 90, note: "Session handling, access control" },
      { name: "Business Logic Testing", level: 85, note: "The flaws scanners structurally miss" },
    ],
  },
  {
    id: "recon",
    title: "Recon & Infrastructure",
    icon: "network",
    blurb: "Mapping the surface before touching anything on it.",
    skills: [
      { name: "Reconnaissance & OSINT", level: 90, note: "Information gathering, asset discovery" },
      { name: "Attack Surface Mapping", level: 90, note: "Subdomains, services, tech fingerprinting" },
      { name: "Network Security Testing", level: 90, note: "Enumeration, misconfiguration" },
      { name: "Mobile Application Security", level: 80, note: "Android application analysis" },
    ],
  },
  {
    id: "code",
    title: "Code & Automation",
    icon: "terminal",
    blurb: "Automating the boring half so the interesting half gets attention.",
    skills: [
      { name: "Python", level: 85, note: "Custom scanners, exploit scripts" },
      { name: "Automated Scanning", level: 95, note: "Self-built tooling, run at scale" },
      { name: "Linux Security Testing", level: 85, note: "Hardening review, privilege escalation" },
      { name: "Bash Scripting", level: 80, note: "Recon pipelines, automation glue" },
      { name: "Source Code Analysis", level: 80, note: "Manual review, taint tracking" },
    ],
  },
];

/** Secondary languages, rendered as a compact strip under the skill groups. */
export const languages = [
  { name: "Python", level: 85 },
  { name: "HTML5", level: 90 },
  { name: "CSS3", level: 90 },
  { name: "JavaScript", level: 80 },
  { name: "PHP", level: 80 },
  { name: "Bash", level: 80 },
  { name: "Ruby", level: 80 },
  { name: "SQL", level: 80 },
];

/* -------------------------------------------------------------------------- */
/*  PROJECTS                                                                  */
/* -------------------------------------------------------------------------- */

export const projectCategories = ["All", "Tooling", "CTF"] as const;

export type ProjectCategory = (typeof projectCategories)[number];

export type Project = {
  id: string;
  title: string;
  category: Exclude<ProjectCategory, "All">;
  summary: string;
  impact: string;
  stack: string[];
  year: string;
  repo?: string;
  writeup?: string;
  featured?: boolean;
  severity?: "Critical" | "High" | "Medium" | "Low";
};

export const projects: Project[] = [
  {
    id: "t4wf1q-x",
    title: "T4WF1Q-X",
    category: "Tooling",
    summary:
      "My own reconnaissance and vulnerability research framework. It handles asset discovery, attack surface mapping and automated checks, then surfaces only what is worth looking at by hand — built because chaining a dozen separate tools for every target was costing more time than the testing itself.",
    impact: "The backbone of my day-to-day bug bounty workflow.",
    stack: ["Python", "Bash", "Linux", "Automation"],
    year: "2025",
    featured: true,
    repo: "https://github.com/Tawfiqimam", // TODO: link the actual repo
  },
  {
    id: "argus",
    title: "Argus — Web Vulnerability Scanner",
    category: "Tooling",
    summary:
      "An automated web vulnerability scanner I wrote to cover the repetitive first pass across a target: common injection points, misconfiguration, exposed endpoints and known weak patterns. Designed for low false positives, because a scanner that cries wolf gets ignored.",
    impact: "Cuts the first pass on a new target from hours to minutes.",
    stack: ["Python", "Web Security", "Automation"],
    year: "2025",
    featured: true,
    repo: "https://github.com/Tawfiqimam", // TODO: link the actual repo
  },
  {
    id: "ctf",
    title: "CTF Writeups & Challenges",
    category: "CTF",
    summary:
      "I solve CTF challenges to keep the practical side sharp — web exploitation, privilege escalation, authentication flaws, cryptography, network security and digital forensics. The writeups focus on the reasoning and the dead ends, not just the working payload.",
    impact: "Hack The Box · TryHackMe · PicoCTF · PortSwigger Web Security Academy.",
    stack: ["Web Exploitation", "PrivEsc", "Cryptography", "Forensics"],
    year: "Ongoing",
    repo: "https://github.com/Tawfiqimam", // TODO: link your writeups repo
  },
];

/* -------------------------------------------------------------------------- */
/*  RESEARCH & DISCLOSURES                                                    */
/* -------------------------------------------------------------------------- */

export type Writeup = {
  id: string;
  title: string;
  kind: "Disclosure" | "Hall of Fame" | "Analysis" | "Writeup";
  /** The program or organisation the report went to. "Undisclosed" is fine. */
  program?: string;
  /** Vulnerability class, e.g. "Authentication & Authorization". */
  category?: string;
  /** CVSS v3.1 base score, if one was assigned. */
  cvss?: number;
  /** Optional — omitted entries simply render without a date. */
  date?: string;
  readTime?: string;
  excerpt: string;
  href?: string;
  cve?: string;
  severity?: "Critical" | "High" | "Medium" | "Low";
};

/* Ordered by severity, not by date — a Critical belongs at the top. */
export const writeups: Writeup[] = [
  {
    id: "w-oauth-ato",
    title: "Account Takeover via OAuth Misconfiguration",
    kind: "Disclosure",
    program: "Decathlon",
    category: "Authentication & Authorization",
    severity: "Critical",
    cvss: 9.4,
    excerpt:
      "An OAuth misconfiguration that could lead to unauthorised account takeover. Found through in-depth manual testing of the authentication flow rather than automated scanning, and disclosed responsibly through Decathlon's security channel.",
  },
  {
    id: "w-session-hijack",
    title: "Full Account Takeover via Session Hijacking",
    kind: "Disclosure",
    program: "Decathlon",
    category: "Authentication & Session Management",
    severity: "Critical",
    cvss: 9.4,
    excerpt:
      "A session management flaw allowing unauthorised access to user accounts and modification of sensitive account data. Identified through manual security testing and disclosed responsibly through Decathlon's security channel.",
  },
  {
    id: "w-paypal",
    title: "OTP Bypass via Security Misconfiguration",
    kind: "Disclosure",
    program: "PayPal",
    category: "Authentication & Authorization",
    severity: "Medium",
    excerpt:
      "An authentication-flow weakness that allowed the one-time-password step to be bypassed. Found by manual analysis of the authentication sequence, reported through PayPal's disclosure channel and triaged as P3.",
  },
  {
    id: "w-teamviewer",
    title: "Password Leakage via Improper Data Handling",
    kind: "Disclosure",
    program: "TeamViewer",
    category: "Information Disclosure",
    severity: "Medium",
    excerpt:
      "Sensitive authentication data exposed through improper handling of password-related values. Identified during independent manual research and reported responsibly to the vendor.",
  },
  {
    id: "w-stripe",
    title: "Hall of Fame Recognition",
    kind: "Hall of Fame",
    program: "Stripe",
    // TODO: add the vulnerability type, severity and a short summary.
    excerpt:
      "Validated security report acknowledged by Stripe's security team, earning a place in their Hall of Fame.",
  },
];

/* -------------------------------------------------------------------------- */
/*  EDUCATION                                                                 */
/* -------------------------------------------------------------------------- */

export type Education = {
  qualification: string;
  abbr: string;
  institution: string;
  period: string;
  status: "Completed" | "In Progress";
  blurb: string;
};

export const education: Education[] = [
  {
    qualification: "Computer Science & Engineering",
    abbr: "B.Sc.",
    institution: "Southeast University, Dhaka",
    period: "Present", // TODO: e.g. "2023 — Present"
    status: "In Progress",
    blurb: "Undergraduate study alongside independent security research.",
  },
  {
    qualification: "Engineering",
    abbr: "Diploma",
    institution: "Pabna Polytechnic Institute, Pabna",
    period: "Completed", // TODO: e.g. "2019 — 2023"
    status: "Completed",
    blurb: "Technical foundation in computing and engineering practice.",
  },
  {
    qualification: "Networking & Infrastructure Track",
    abbr: "CCNA",
    institution: "Creative IT Institute, Dhaka",
    period: "Training", // TODO: add the year
    status: "Completed",
    blurb: "Routing, switching and network fundamentals.",
  },
];

/* -------------------------------------------------------------------------- */
/*  EXPERIENCE                                                                */
/* -------------------------------------------------------------------------- */

export type Role = {
  title: string;
  org: string;
  period: string;
  current?: boolean;
  summary: string;
  highlights: string[];
  tags: string[];
};

// TODO: replace every `period` below with your real dates.
export const experience: Role[] = [
  {
    title: "Independent Security Researcher & Bug Bounty Hunter",
    org: "YesWeHack · HackerOne · Bugcrowd",
    period: "2023 — Present",
    current: true,
    summary:
      "Independent vulnerability research across public and private bug bounty programs, focused on web, API and mobile targets. Manual testing first, with my own tooling handling reconnaissance and the repetitive first pass.",
    highlights: [
      "Submitted 300+ vulnerability reports, with 100+ Hall of Fame recognitions.",
      "Reported 50+ Critical severity findings, including account takeovers scoring CVSS 9.4.",
      "Disclosed vulnerabilities to PayPal, Decathlon, TeamViewer and Stripe.",
      "Built and maintain T4WF1Q-X and Argus, the tooling behind my research workflow.",
    ],
    tags: ["Bug Bounty", "Web Security", "API Security", "Responsible Disclosure"],
  },
  {
    title: "IT Infrastructure — Computer Club",
    org: "Southeast University Computer Club",
    period: "2024 — Present", // TODO: confirm the dates
    current: true,
    summary:
      "Part of the IT Infrastructure team at my university's computer club, supporting the technical side of club activities and coordinating with members on events and initiatives.",
    highlights: [
      "Supported and maintained the technical infrastructure behind club activities.",
      "Coordinated across the team on organisational and technical initiatives.",
      "Mentored and worked alongside members on practical problem solving.",
    ],
    tags: ["Leadership", "IT Infrastructure", "Teamwork"],
  },
  {
    title: "Junior Security Researcher",
    org: "iTech Company",
    period: "2024 — 2025",
    summary:
      "Security testing and vulnerability research in a team setting, covering web application assessment and the reporting work that turns a finding into something a developer can act on.",
    highlights: [
      "Performed web application security assessments and vulnerability validation.",
      "Documented findings with reproduction steps and remediation guidance.",
    ],
    tags: ["Web Security", "Vulnerability Assessment", "Reporting"],
  },
  {
    title: "Junior IT Officer",
    org: "World Wide Consultancy",
    period: "2023 — 2024",
    summary:
      "Day-to-day IT operations and systems support, with responsibility for keeping infrastructure patched and access controls sane — the defensive side that still informs how I write findings.",
    highlights: [
      "Maintained systems, user access and network infrastructure.",
      "Handled technical support and routine security hygiene.",
    ],
    tags: ["IT Operations", "Systems", "Networking"],
  },
  {
    title: "Intern — Networking (CCNA Track)",
    org: "Creative IT Institute",
    period: "2023",
    summary:
      "Hands-on networking training covering routing, switching and infrastructure fundamentals — the groundwork for the network-side testing I do now.",
    highlights: [
      "Completed practical routing and switching coursework.",
      "Built a working foundation in network protocols and topology.",
    ],
    tags: ["Networking", "CCNA", "Infrastructure"],
  },
];

/* -------------------------------------------------------------------------- */
/*  ARSENAL                                                                   */
/* -------------------------------------------------------------------------- */

export type Tool = {
  name: string;
  category: "Custom" | "Web" | "Network" | "Mobile" | "Platform";
  mastery: number;
  use: string;
};

/**
 * TODO — REVIEW THIS LIST.
 * Your own two tools are here because you named them. The rest is the standard
 * web/bug-bounty toolkit inferred from your skill list — delete anything you
 * don't actually use and add what's missing. Don't list a tool you can't
 * discuss in an interview.
 */
export const arsenal: Tool[] = [
  { name: "T4WF1Q-X", category: "Custom", mastery: 95, use: "My recon, automation & research framework" },
  { name: "Argus", category: "Custom", mastery: 92, use: "My web vulnerability scanner" },
  { name: "Burp Suite", category: "Web", mastery: 95, use: "Interception, manual web & API testing" },
  { name: "Nuclei", category: "Web", mastery: 85, use: "Template-driven surface scanning" },
  { name: "ffuf", category: "Web", mastery: 85, use: "Content & parameter discovery" },
  { name: "Nmap", category: "Network", mastery: 90, use: "Host discovery, service enumeration" },
  { name: "Wireshark", category: "Network", mastery: 80, use: "Traffic analysis" },
  { name: "MobSF", category: "Mobile", mastery: 78, use: "Android application analysis" },
  { name: "Kali Linux", category: "Platform", mastery: 90, use: "Primary testing platform" },
  { name: "Python", category: "Platform", mastery: 85, use: "Custom tooling and exploit scripts" },
];

/* -------------------------------------------------------------------------- */
/*  PRELOADER BOOT SEQUENCE                                                   */
/* -------------------------------------------------------------------------- */

export const bootSequence: string[] = [
  "initialising secure shell ...",
  "mounting /dev/portfolio ...",
  "loading cryptographic modules ...",
  "verifying payload signature ... OK",
  "establishing encrypted channel ...",
  "access granted",
];
