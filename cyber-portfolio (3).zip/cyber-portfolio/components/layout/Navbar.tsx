"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, Shield } from "lucide-react";
import { navItems, site } from "@/lib/site";
import { useActiveSection, useScrolled } from "@/lib/hooks";
import { cn } from "@/lib/utils";
import { EASE_OUT_EXPO } from "@/lib/motion";

const ids = navItems.map((item) => item.id);

export default function Navbar() {
  const scrolled = useScrolled(32);
  const active = useActiveSection(ids);
  const [open, setOpen] = useState(false);

  const panelRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  /* Mobile sheet: lock scroll, trap Tab inside the panel, close on Escape,
     and return focus to the trigger on close. */
  useEffect(() => {
    if (!open) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const focusables = () =>
      Array.from(
        panelRef.current?.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled])',
        ) ?? [],
      );

    focusables()[0]?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        return;
      }

      if (event.key !== "Tab") return;

      const items = focusables();
      if (items.length === 0) return;

      const first = items[0];
      const last = items[items.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
      triggerRef.current?.focus();
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-[100] transition-all duration-300 ease-out",
        scrolled
          ? "border-b border-line bg-void/80 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <nav
        aria-label="Primary"
        className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-6 lg:h-18 lg:px-10"
      >
        {/* Wordmark */}
        <Link
          href="#top"
          className="group flex min-h-11 items-center gap-2.5 font-mono text-sm"
          aria-label={`${site.name} — back to top`}
        >
          <Shield
            className="size-4 text-matrix transition-transform duration-300 group-hover:scale-110"
            aria-hidden="true"
          />
          <span className="font-medium text-bone">
            {site.handle}
            <span className="text-matrix">@</span>
            sec
          </span>
        </Link>

        {/* Desktop navigation */}
        <ul className="hidden items-center gap-0.5 lg:flex">
          {navItems.map((item) => {
            const isActive = active === item.id;
            return (
              <li key={item.id}>
                <Link
                  href={`#${item.id}`}
                  aria-current={isActive ? "true" : undefined}
                  className={cn(
                    "relative flex min-h-11 items-center px-3.5 font-mono text-[0.8rem] transition-colors duration-200",
                    isActive
                      ? "text-matrix"
                      : "text-ash hover:text-bone",
                  )}
                >
                  {item.label}
                  {isActive && (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute inset-x-2 -bottom-px h-px bg-matrix"
                      transition={{ duration: 0.3, ease: EASE_OUT_EXPO }}
                    />
                  )}
                </Link>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-2">
          <a
            href={`mailto:${site.email}`}
            className="clip-corner-sm hidden min-h-11 items-center border border-matrix/45 bg-matrix/10 px-4 font-mono text-[0.8rem] text-matrix transition-colors duration-200 hover:bg-matrix/20 sm:inline-flex"
          >
            Get in touch
          </a>

          {/* Mobile trigger — 44×44 minimum */}
          <button
            ref={triggerRef}
            type="button"
            onClick={() => setOpen(true)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label="Open navigation menu"
            className="flex size-11 cursor-pointer items-center justify-center border border-line-bright text-bone transition-colors duration-200 hover:border-matrix/50 hover:text-matrix lg:hidden"
          >
            <Menu className="size-5" aria-hidden="true" />
          </button>
        </div>
      </nav>

      {/* Mobile sheet */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-nav"
            role="dialog"
            aria-modal="true"
            aria-label="Navigation"
            ref={panelRef}
            className="fixed inset-0 z-[110] bg-void/97 backdrop-blur-xl lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
          >
            <div className="scanlines pointer-events-none absolute inset-0 opacity-50" />

            <div className="relative flex h-16 items-center justify-between px-6">
              <span className="font-mono text-xs tracking-[0.25em] text-slate uppercase">
                Navigation
              </span>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close navigation menu"
                className="flex size-11 cursor-pointer items-center justify-center border border-line-bright text-bone transition-colors duration-200 hover:border-matrix/50 hover:text-matrix"
              >
                <X className="size-5" aria-hidden="true" />
              </button>
            </div>

            <ul className="relative mt-6 flex flex-col px-6">
              {navItems.map((item, i) => (
                <motion.li
                  key={item.id}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.04 * i, duration: 0.3 }}
                  className="border-b border-line"
                >
                  <Link
                    href={`#${item.id}`}
                    onClick={() => setOpen(false)}
                    aria-current={active === item.id ? "true" : undefined}
                    className={cn(
                      "flex min-h-14 items-center justify-between gap-4 font-mono text-lg transition-colors duration-200",
                      active === item.id ? "text-matrix" : "text-bone",
                    )}
                  >
                    <span>{item.label}</span>
                    <span
                      aria-hidden="true"
                      className="font-mono text-xs text-slate tabular-nums"
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                  </Link>
                </motion.li>
              ))}
            </ul>

            <div className="relative mt-8 px-6">
              <a
                href={`mailto:${site.email}`}
                onClick={() => setOpen(false)}
                className="clip-corner flex min-h-12 items-center justify-center border border-matrix/50 bg-matrix/12 font-mono text-sm text-matrix"
              >
                Get in touch
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
