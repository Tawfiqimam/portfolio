import { site, socials } from "@/lib/site";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative z-10 border-t border-line bg-abyss/60">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-10 font-mono text-xs text-slate sm:flex-row sm:items-center sm:justify-between lg:px-10">
        <div className="space-y-1.5">
          <p className="text-ash">
            © {year} {site.name}. All findings disclosed responsibly.
          </p>
          <p>
            <span className="text-matrix-dim">$</span> uptime — built with
            Next.js, deployed on the edge
          </p>
        </div>

        <ul className="flex flex-wrap items-center gap-x-5 gap-y-2">
          {socials.map((link) => (
            <li key={link.label}>
              <a
                href={link.href}
                target={link.icon === "mail" ? undefined : "_blank"}
                rel={link.icon === "mail" ? undefined : "noopener noreferrer"}
                className="inline-flex min-h-11 min-w-11 items-center justify-center text-ash transition-colors duration-200 hover:text-matrix"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </footer>
  );
}
