"use client";

import { useEffect, useRef, useState } from "react";
import { useHasFinePointer, usePrefersReducedMotion } from "@/lib/hooks";

/**
 * Custom cursor: a precise 4px dot plus a lagging reticle ring that opens up
 * over interactive targets.
 *
 * Accessibility guardrails, because replacing the system cursor is a real
 * risk and not a free win:
 *  - Only ever active on `(pointer: fine)`. Touch keeps the native behaviour
 *    and the native cursor is never hidden there.
 *  - Under `prefers-reduced-motion` the ring stops lagging and tracks
 *    one-to-one, so there is no trailing movement to track.
 *  - High-contrast matrix green on near-black, and the ring grows rather
 *    than shrinks on targets, so the pointer is never harder to locate than
 *    the system one.
 *  - The native cursor is restored on unmount and when the pointer leaves
 *    the window.
 *
 * Position is written straight to the DOM with `transform` inside a rAF loop
 * rather than through React state, so pointer movement never triggers a
 * re-render.
 */
export default function CustomCursor() {
  const fine = useHasFinePointer();
  const reduce = usePrefersReducedMotion();

  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const [hidden, setHidden] = useState(true);
  const [hot, setHot] = useState(false);

  useEffect(() => {
    if (!fine) return;

    document.body.dataset.customCursor = "on";

    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    const ring = { ...target };
    /* 1 = no lag (reduced motion), 0.18 = springy trail. */
    const ease = reduce ? 1 : 0.18;
    let raf = 0;

    const onMove = (event: PointerEvent) => {
      target.x = event.clientX;
      target.y = event.clientY;
      setHidden(false);

      const el = event.target as HTMLElement | null;
      setHot(
        Boolean(
          el?.closest(
            'a, button, [role="button"], input, textarea, select, [data-cursor="hot"]',
          ),
        ),
      );
    };

    const onLeave = () => setHidden(true);
    const onEnter = () => setHidden(false);

    const tick = () => {
      raf = requestAnimationFrame(tick);

      ring.x += (target.x - ring.x) * ease;
      ring.y += (target.y - ring.y) * ease;

      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${target.x}px, ${target.y}px, 0) translate(-50%, -50%)`;
      }
      if (ringRef.current) {
        ringRef.current.style.transform = `translate3d(${ring.x}px, ${ring.y}px, 0) translate(-50%, -50%)`;
      }
    };

    raf = requestAnimationFrame(tick);
    window.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerleave", onLeave);
    document.addEventListener("pointerenter", onEnter);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerleave", onLeave);
      document.removeEventListener("pointerenter", onEnter);
      delete document.body.dataset.customCursor;
    };
  }, [fine, reduce]);

  if (!fine) return null;

  return (
    <div
      aria-hidden="true"
      data-decorative
      className="pointer-events-none fixed inset-0 z-[120] hidden sm:block"
      style={{ opacity: hidden ? 0 : 1, transition: "opacity 200ms ease-out" }}
    >
      {/* Precise dot — always 1:1 with the real pointer position. */}
      <div
        ref={dotRef}
        className="absolute top-0 left-0 size-1 rounded-full bg-matrix shadow-glow-sm"
      />

      {/* Reticle ring */}
      <div
        ref={ringRef}
        className="absolute top-0 left-0 flex items-center justify-center rounded-full border transition-[width,height,border-color,background-color] duration-200 ease-out"
        style={{
          width: hot ? 44 : 26,
          height: hot ? 44 : 26,
          borderColor: hot
            ? "rgba(0, 255, 65, 0.9)"
            : "rgba(0, 255, 65, 0.38)",
          backgroundColor: hot ? "rgba(0, 255, 65, 0.1)" : "transparent",
        }}
      >
        {/* Crosshair ticks, only while over a target. */}
        <span
          className="absolute h-px bg-matrix/70 transition-all duration-200"
          style={{ width: hot ? 10 : 0, left: -14 }}
        />
        <span
          className="absolute h-px bg-matrix/70 transition-all duration-200"
          style={{ width: hot ? 10 : 0, right: -14 }}
        />
      </div>
    </div>
  );
}
