"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { bootSequence, site } from "@/lib/site";
import { usePrefersReducedMotion } from "@/lib/hooks";
import { EASE_OUT_EXPO } from "@/lib/motion";

const SESSION_KEY = "boot-complete";
const LINE_MS = 260;
const HOLD_MS = 520;

/**
 * Terminal boot preloader.
 *
 * Deliberately short (under ~2s) and always skippable — a preloader that
 * cannot be dismissed is a tax on every repeat visit, not a flourish.
 *
 *  - Replays once per session only (`sessionStorage`).
 *  - Skipped outright under `prefers-reduced-motion`.
 *  - Escape or the Skip button dismisses it immediately.
 *  - Scroll is locked while it is up, and the lock is always released.
 *  - The page content is in the DOM underneath the whole time, so crawlers
 *    and no-JS visitors are unaffected.
 */
export default function Preloader() {
  const reduce = usePrefersReducedMotion();
  const [active, setActive] = useState(true);
  const [step, setStep] = useState(0);
  const skipRef = useRef<HTMLButtonElement>(null);

  // Decide whether to run at all. Runs after mount, so no hydration mismatch.
  useEffect(() => {
    /* Reading sessionStorage can throw outright under some privacy modes,
       not just fail — so the read is guarded as well as the write. */
    let seen = false;
    try {
      seen = window.sessionStorage?.getItem(SESSION_KEY) === "1";
    } catch {
      seen = false;
    }

    if (seen || reduce) {
      setActive(false);
      return;
    }

    skipRef.current?.focus();
  }, [reduce]);

  // Advance the boot log.
  useEffect(() => {
    if (!active) return;

    if (step >= bootSequence.length) {
      const done = setTimeout(() => setActive(false), HOLD_MS);
      return () => clearTimeout(done);
    }

    const next = setTimeout(() => setStep((s) => s + 1), LINE_MS);
    return () => clearTimeout(next);
  }, [active, step]);

  // Scroll lock + Escape to dismiss.
  useEffect(() => {
    if (!active) return;

    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActive(false);
    };
    window.addEventListener("keydown", onKey);

    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [active]);

  // Remember completion so the sequence does not repeat on navigation.
  useEffect(() => {
    if (active) return;
    try {
      window.sessionStorage?.setItem(SESSION_KEY, "1");
    } catch {
      /* Private browsing can throw on write — the preloader simply replays. */
    }

    /* The Skip button held focus and is now gone. Chromium keeps the
       sequential-focus starting point where that element was, which is past
       the skip link — so the first Tab would miss it. Focusing the body
       resets the starting point to the top of the document. */
    const body = document.body;
    body.setAttribute("tabindex", "-1");
    body.focus({ preventScroll: true });
    body.removeAttribute("tabindex");
  }, [active]);

  const progress = Math.round(
    (Math.min(step, bootSequence.length) / bootSequence.length) * 100,
  );

  return (
    <AnimatePresence>
      {active && (
        <motion.div
          key="preloader"
          className="fixed inset-0 z-[150] flex items-center justify-center bg-void px-6"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.45, ease: EASE_OUT_EXPO }}
        >
          <div className="scanlines pointer-events-none absolute inset-0 opacity-70" />
          <div className="noise pointer-events-none absolute inset-0 opacity-[0.04]" />

          <div className="relative w-full max-w-md">
            <p className="mb-5 font-mono text-[0.7rem] tracking-[0.3em] text-slate uppercase">
              {site.name} // secure boot
            </p>

            <div
              className="min-h-[9.5rem] space-y-1 font-mono text-xs sm:text-sm"
              /* Announced as one completed status rather than line by line. */
              role="status"
              aria-live="polite"
              aria-label={
                step >= bootSequence.length
                  ? "Boot sequence complete. Access granted."
                  : "Loading"
              }
            >
              {bootSequence.slice(0, step).map((line, i) => {
                const isFinal = i === bootSequence.length - 1;
                return (
                  <motion.p
                    key={line}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2 }}
                    className={
                      isFinal
                        ? "text-glow pt-1 font-medium text-matrix"
                        : "text-ash"
                    }
                  >
                    <span className="mr-2 text-matrix-dim select-none">
                      {isFinal ? ">>" : "::"}
                    </span>
                    {line}
                  </motion.p>
                );
              })}
            </div>

            {/* Progress */}
            <div className="mt-6">
              <div className="mb-2 flex items-center justify-between font-mono text-[0.65rem] text-slate">
                <span>establishing session</span>
                <span className="tabular-nums text-matrix">{progress}%</span>
              </div>
              <div
                role="progressbar"
                aria-valuenow={progress}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="Boot progress"
                className="h-0.5 w-full overflow-hidden bg-surface-3"
              >
                <motion.div
                  className="h-full origin-left bg-matrix"
                  animate={{ scaleX: progress / 100 }}
                  initial={{ scaleX: 0 }}
                  style={{ width: "100%" }}
                  transition={{ duration: 0.22, ease: "linear" }}
                />
              </div>
            </div>

            <button
              ref={skipRef}
              type="button"
              onClick={() => setActive(false)}
              className="mt-7 min-h-11 cursor-pointer font-mono text-xs text-slate underline decoration-dotted underline-offset-4 transition-colors duration-200 hover:text-matrix"
            >
              Skip intro [esc]
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
