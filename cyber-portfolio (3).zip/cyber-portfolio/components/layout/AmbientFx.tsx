"use client";

import { usePrefersReducedMotion } from "@/lib/hooks";

/**
 * Page-wide atmospheric layer: film noise, scanlines, a slow CRT sweep and a
 * corner vignette. Fixed, pointer-events-none, aria-hidden and stripped in
 * print. Opacities are deliberately low — this must never cost text contrast.
 */
export default function AmbientFx() {
  const reduce = usePrefersReducedMotion();

  return (
    <div
      aria-hidden="true"
      data-decorative
      className="pointer-events-none fixed inset-0 z-50 overflow-hidden select-none"
    >
      {/* Film grain */}
      <div className="noise absolute inset-0 opacity-[0.035] mix-blend-overlay" />

      {/* Scanlines */}
      <div className="scanlines absolute inset-0 opacity-60" />

      {/* Single CRT sweep travelling down the viewport */}
      {!reduce && (
        <div className="animate-scan-sweep absolute inset-x-0 top-0 h-24 bg-linear-to-b from-transparent via-matrix/[0.045] to-transparent" />
      )}

      {/* Edge vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_70%_at_50%_50%,transparent_55%,rgba(0,0,0,0.5)_100%)]" />
    </div>
  );
}
