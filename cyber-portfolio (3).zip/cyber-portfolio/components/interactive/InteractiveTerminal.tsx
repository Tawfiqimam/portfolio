"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  arsenal,
  education,
  experience,
  languages,
  projects,
  site,
  skillGroups,
  socials,
  writeups,
} from "@/lib/site";
import TerminalWindow from "@/components/ui/TerminalWindow";
import { cn } from "@/lib/utils";

type Entry = {
  id: number;
  /** undefined for the banner, which has no prompt line. */
  input?: string;
  output: string[];
  tone?: "default" | "error" | "success";
};

const MAX_ENTRIES = 40;

const BANNER = [
  `${site.name} — interactive shell v1.0`,
  "",
  "Type a command, or `help` to list what is available.",
  "Tab completes. ↑ / ↓ walks history.",
];

/* Commands are pure functions of the site data, so the shell can never drift
   out of sync with the rest of the page. */
const commands: Record<
  string,
  { describe: string; run: (args: string[]) => string[] }
> = {
  help: {
    describe: "List available commands",
    run: () => [
      "AVAILABLE COMMANDS",
      "",
      ...Object.entries(commands).map(
        ([name, command]) => `  ${name.padEnd(12)} ${command.describe}`,
      ),
    ],
  },
  whoami: {
    describe: "Print the operator identity",
    run: () => [
      site.name,
      site.roles.join(" | "),
      "",
      `location : ${site.location}`,
      `status   : ${site.availability}`,
    ],
  },
  mission: {
    describe: "State the operating principle",
    run: () => [site.tagline],
  },
  skills: {
    describe: "Show competency breakdown",
    run: () =>
      skillGroups.flatMap((group) => [
        `[${group.title}]`,
        ...group.skills.map(
          (skill) =>
            `  ${skill.name.padEnd(28)} ${"█".repeat(
              Math.round(skill.level / 10),
            )}${"░".repeat(10 - Math.round(skill.level / 10))} ${skill.level}%`,
        ),
        "",
      ]),
  },
  projects: {
    describe: "List published project work",
    run: () => [
      `${projects.length} projects on record`,
      "",
      ...projects.map(
        (project) =>
          `  ${project.year.padEnd(10)} [${project.category.padEnd(8)}] ${project.title}`,
      ),
    ],
  },
  research: {
    describe: "List writeups and disclosures",
    run: () => [
      `${writeups.length} published findings`,
      "",
      ...writeups.map(
        (entry) =>
          `  [${(entry.program ?? "—").padEnd(12)}] ${entry.kind.padEnd(13)} ${entry.title}`,
      ),
    ],
  },
  education: {
    describe: "Show education",
    run: () =>
      education.map(
        (item) =>
          `  ${item.abbr.padEnd(9)} ${item.qualification.padEnd(34)} ${item.institution}`,
      ),
  },
  experience: {
    describe: "Print the role history",
    run: () =>
      experience.flatMap((role) => [
        `${role.period}`,
        `  ${role.title} — ${role.org}`,
        "",
      ]),
  },
  arsenal: {
    describe: "List tooling and proficiency",
    run: () =>
      arsenal.map(
        (tool) =>
          `  ${tool.name.padEnd(16)} ${String(tool.mastery).padStart(3)}%  ${tool.use}`,
      ),
  },
  contact: {
    describe: "Show contact channels",
    run: () => [
      `email : ${site.email}`,
      ...socials
        .filter((link) => link.icon !== "mail")
        .map((link) => `${link.label.toLowerCase().padEnd(6)}: ${link.handle}`),
    ],
  },
  langs: {
    describe: "Show programming languages",
    run: () =>
      languages.map(
        (l) =>
          `  ${l.name.padEnd(12)} ${"\u2588".repeat(Math.round(l.level / 10))}${"\u2591".repeat(
            10 - Math.round(l.level / 10),
          )} ${l.level}%`,
      ),
  },
  ls: {
    describe: "List page sections",
    run: () => [
      "about/  skills/  projects/  research/",
      "education/  experience/  arsenal/  contact/",
    ],
  },
  date: {
    describe: "Print the current timestamp",
    run: () => [new Date().toUTCString()],
  },
  sudo: {
    describe: "Attempt privilege escalation",
    run: (args) => [
      args.length > 0
        ? `sudo: ${args[0]}: command not permitted`
        : "sudo: a command is required",
      "",
      "Nice try. This shell runs unprivileged on purpose —",
      "which is the same advice I give in every report.",
    ],
  },
  clear: {
    describe: "Clear the screen",
    run: () => [],
  },
};

const names = Object.keys(commands);

export default function InteractiveTerminal() {
  const [entries, setEntries] = useState<Entry[]>([
    { id: 0, output: BANNER },
  ]);
  const [value, setValue] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  const inputRef = useRef<HTMLInputElement>(null);
  const logRef = useRef<HTMLDivElement>(null);
  const nextId = useRef(1);

  // Keep the newest line in view without yanking the whole page around.
  useEffect(() => {
    const log = logRef.current;
    if (log) log.scrollTop = log.scrollHeight;
  }, [entries]);

  const submit = useCallback(
    (raw: string) => {
      const trimmed = raw.trim();
      if (trimmed === "") return;

      const [name, ...args] = trimmed.split(/\s+/);
      const key = name.toLowerCase();

      setHistory((prev) => [trimmed, ...prev].slice(0, 50));
      setHistoryIndex(-1);
      setValue("");

      if (key === "clear") {
        setEntries([]);
        return;
      }

      const command = commands[key];

      const entry: Entry = command
        ? { id: nextId.current++, input: trimmed, output: command.run(args) }
        : {
            id: nextId.current++,
            input: trimmed,
            tone: "error",
            output: [
              `command not found: ${key}`,
              "Run `help` to see what this shell accepts.",
            ],
          };

      setEntries((prev) => [...prev, entry].slice(-MAX_ENTRIES));
    },
    [],
  );

  const onKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      event.preventDefault();
      submit(value);
      return;
    }

    // Tab completion against the command list.
    if (event.key === "Tab") {
      event.preventDefault();
      const partial = value.trim().toLowerCase();
      if (!partial) return;
      const match = names.find((name) => name.startsWith(partial));
      if (match) setValue(match);
      return;
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      if (history.length === 0) return;
      const index = Math.min(historyIndex + 1, history.length - 1);
      setHistoryIndex(index);
      setValue(history[index]);
      return;
    }

    if (event.key === "ArrowDown") {
      event.preventDefault();
      const index = historyIndex - 1;
      if (index < 0) {
        setHistoryIndex(-1);
        setValue("");
      } else {
        setHistoryIndex(index);
        setValue(history[index]);
      }
    }
  };

  return (
    <TerminalWindow
      title={`${site.handle}@shell — interactive`}
      status="ready"
      bodyClassName="p-0"
    >
      {/* Output log */}
      <div
        ref={logRef}
        /* Focusable so keyboard users can scroll the log independently of
           the input, and announced politely as commands resolve. */
        tabIndex={0}
        role="log"
        aria-live="polite"
        aria-label="Terminal output"
        className="max-h-80 min-h-64 overflow-y-auto px-4 py-4 text-[0.78rem] leading-relaxed sm:px-5"
      >
        {entries.map((entry) => (
          <div key={entry.id} className="mb-3 last:mb-0">
            {entry.input !== undefined && (
              <p className="flex flex-wrap gap-x-2">
                <span className="text-matrix select-none">
                  root@{site.handle}:~$
                </span>
                <span className="text-bone">{entry.input}</span>
              </p>
            )}

            {entry.output.map((line, i) => (
              <p
                key={i}
                className={cn(
                  "whitespace-pre-wrap break-words",
                  entry.tone === "error"
                    ? "text-critical"
                    : entry.tone === "success"
                      ? "text-matrix"
                      : "text-ash",
                )}
              >
                {line || " "}
              </p>
            ))}
          </div>
        ))}
      </div>

      {/* Prompt */}
      <form
        onSubmit={(event) => {
          event.preventDefault();
          submit(value);
        }}
        className="flex items-center gap-2 border-t border-line bg-black/40 px-4 py-3 sm:px-5"
      >
        <label htmlFor="shell-input" className="shrink-0 text-matrix select-none">
          root@{site.handle}:~$
        </label>
        <input
          id="shell-input"
          ref={inputRef}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          onKeyDown={onKeyDown}
          autoComplete="off"
          autoCapitalize="off"
          spellCheck={false}
          placeholder="help"
          aria-describedby="shell-hint"
          className="min-h-6 w-full bg-transparent font-mono text-[0.8rem] text-bone caret-matrix outline-none placeholder:text-slate/60"
        />
      </form>

      <p id="shell-hint" className="sr-only">
        Type a command and press Enter. Press Tab to complete, or the up and
        down arrows to recall previous commands. Try: help, whoami, projects,
        research, arsenal, contact.
      </p>
    </TerminalWindow>
  );
}
