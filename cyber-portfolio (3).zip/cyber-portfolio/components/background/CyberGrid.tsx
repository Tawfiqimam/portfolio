"use client";

import { motion, useReducedMotion } from "framer-motion";

/**
 * Static perspective grid plus a slow radar sweep. Decorative; both the grid
 * and the sweep are masked so they fade well before the content edges.
 */
export default function CyberGrid() {
  const reduce = useReducedMotion();

  return (
    <div
      aria-hidden="true"
      data-decorative
      className="pointer-events-none absolute inset-0 overflow-hidden"
    >
      {/* Masked grid */}
      <div className="cyber-grid absolute inset-0" />

      {/* Horizon glow */}
      <div className="absolute inset-x-0 top-1/2 h-px bg-linear-to-r from-transparent via-matrix/25 to-transparent" />

      {/* Radar sweep — a single rotating conic gradient, GPU-composited. */}
      {!reduce && (
        <motion.div
          className="absolute top-1/2 left-1/2 size-[min(140vw,1200px)] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-[0.16]"
          style={{
            background:
              "conic-gradient(from 0deg, transparent 0deg, transparent 300deg, rgba(0,255,65,0.5) 350deg, transparent 360deg)",
            maskImage:
              "radial-gradient(circle, #000 0%, rgba(0,0,0,0.5) 45%, transparent 68%)",
            WebkitMaskImage:
              "radial-gradient(circle, #000 0%, rgba(0,0,0,0.5) 45%, transparent 68%)",
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 14, ease: "linear", repeat: Infinity }}
        />
      )}

      {/* Vignette so the centre content always wins on contrast */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_45%,transparent_0%,rgba(5,5,5,0.55)_70%,var(--color-void)_100%)]" />
    </div>
  );
}
