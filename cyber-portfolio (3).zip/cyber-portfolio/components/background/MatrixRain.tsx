"use client";

import { useEffect, useRef } from "react";
import { usePrefersReducedMotion } from "@/lib/hooks";
import { cn } from "@/lib/utils";

/* Halfwidth katakana + digits + operators: the canonical glyph set, kept to
   monospaced halfwidth forms so every column measures the same width. */
const GLYPHS =
  "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789<>/\\[]{}=+*#$%&@!?~^|";

type MatrixRainProps = {
  className?: string;
  /** Column width in CSS px. Larger = fewer, chunkier columns. */
  fontSize?: number;
  /** 0–1. Chance per frame that an idle column starts falling. */
  spawnRate?: number;
  /** Target frames per second. Capped to keep the main thread free. */
  fps?: number;
};

/**
 * Canvas digital rain.
 *
 * Performance and courtesy constraints, all deliberate:
 *  - Honours `prefers-reduced-motion` by never starting the loop.
 *  - Pauses entirely when the tab is hidden (`visibilitychange`).
 *  - Pauses when scrolled out of view (`IntersectionObserver`).
 *  - Frame-rate capped, so it does not compete with scroll for the main thread.
 *  - Device-pixel-ratio aware, clamped at 2 so 3x phones do not render
 *    nine times the pixels for a decorative background.
 *  - Resize is debounced and re-derives the column grid.
 */
export default function MatrixRain({
  className,
  fontSize = 15,
  spawnRate = 0.018,
  fps = 30,
}: MatrixRainProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const reduce = usePrefersReducedMotion();

  useEffect(() => {
    if (reduce) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let columns = 0;
    /** Head position per column, in rows. -1 means the column is idle. */
    let drops: number[] = [];
    let raf = 0;
    let lastFrame = 0;
    let visible = true;
    let onScreen = true;

    const frameBudget = 1000 / fps;

    const setup = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = canvas.clientWidth;
      height = canvas.clientHeight;

      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      columns = Math.ceil(width / fontSize);
      drops = Array.from({ length: columns }, () =>
        Math.random() < 0.25 ? Math.floor(Math.random() * (height / fontSize)) : -1,
      );

      ctx.font = `${fontSize}px ui-monospace, monospace`;
      ctx.textBaseline = "top";
    };

    const draw = (time: number) => {
      raf = requestAnimationFrame(draw);

      if (!visible || !onScreen) return;
      if (time - lastFrame < frameBudget) return;
      lastFrame = time;

      /* Translucent wipe instead of clearRect: this is what produces the
         trailing tail behind each glyph. */
      ctx.fillStyle = "rgba(5, 5, 5, 0.085)";
      ctx.fillRect(0, 0, width, height);

      const rows = height / fontSize;

      for (let i = 0; i < columns; i++) {
        const y = drops[i];

        if (y < 0) {
          if (Math.random() < spawnRate) drops[i] = 0;
          continue;
        }

        const glyph = GLYPHS[(Math.random() * GLYPHS.length) | 0];
        const x = i * fontSize;
        const py = y * fontSize;

        // Bright head.
        ctx.fillStyle = "rgba(190, 255, 210, 0.92)";
        ctx.fillText(glyph, x, py);

        // Dimmer glyph one row up, to imply a tail without a second pass.
        if (y > 0) {
          ctx.fillStyle = "rgba(0, 255, 65, 0.42)";
          ctx.fillText(
            GLYPHS[(Math.random() * GLYPHS.length) | 0],
            x,
            py - fontSize,
          );
        }

        drops[i] = y > rows + Math.random() * 24 ? -1 : y + 1;
      }
    };

    setup();
    raf = requestAnimationFrame(draw);

    let resizeTimer: ReturnType<typeof setTimeout>;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(setup, 180);
    };

    const onVisibility = () => {
      visible = document.visibilityState === "visible";
    };

    const observer = new IntersectionObserver(
      ([entry]) => {
        onScreen = entry.isIntersecting;
      },
      { threshold: 0 },
    );
    observer.observe(canvas);

    window.addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(resizeTimer);
      observer.disconnect();
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [reduce, fontSize, spawnRate, fps]);

  /* Reduced motion: a static, very faint glyph wash is still on-brand and
     costs one paint. Rendered as CSS, not canvas. */
  if (reduce) {
    return (
      <div
        aria-hidden="true"
        data-decorative
        className={cn(
          "pointer-events-none absolute inset-0 opacity-[0.07]",
          "bg-[repeating-linear-gradient(to_right,rgba(0,255,65,0.5)_0_1px,transparent_1px_15px)]",
          className,
        )}
      />
    );
  }

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      data-decorative
      className={cn("pointer-events-none absolute inset-0 size-full", className)}
    />
  );
}
