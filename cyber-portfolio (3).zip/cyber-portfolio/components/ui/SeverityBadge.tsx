import { cn } from "@/lib/utils";

export type Severity = "Critical" | "High" | "Medium" | "Low";

const styles: Record<Severity, string> = {
  Critical: "border-critical/45 bg-critical/12 text-critical",
  High: "border-high/45 bg-high/12 text-high",
  Medium: "border-medium/45 bg-medium/12 text-medium",
  Low: "border-low/45 bg-low/12 text-low",
};

/**
 * Severity is the only place red appears on this site. The level is written
 * out as text rather than encoded in colour alone, so it survives both
 * colour-blindness and a greyscale print.
 */
export default function SeverityBadge({
  level,
  className,
}: {
  level: Severity;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "clip-corner-sm inline-flex shrink-0 items-center gap-1.5 border px-2 py-0.5",
        "font-mono text-[0.65rem] font-medium tracking-[0.14em] uppercase",
        styles[level],
        className,
      )}
    >
      <span
        aria-hidden="true"
        className="size-1.5 rounded-full bg-current"
      />
      {level}
    </span>
  );
}
