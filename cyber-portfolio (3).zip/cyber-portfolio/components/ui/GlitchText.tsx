"use client";

import { useEffect, useState } from "react";
import { useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

type GlitchTextProps = {
  text: string;
  className?: string;
  /** Fire the glitch automatically on an interval rather than on hover. */
  auto?: boolean;
  /** Milliseconds between automatic bursts. */
  interval?: number;
};

/**
 * RGB-split glitch. The real text sits in the DOM once; the two offset
 * colour layers are pseudo-elements driven from `data-glitch`, so screen
 * readers and search engines only ever see the single clean string.
 */
export default function GlitchText({
  text,
  className,
  auto = false,
  interval = 5200,
}: GlitchTextProps) {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (!auto || reduce) return;

    let timeout: ReturnType<typeof setTimeout>;
    const id = setInterval(() => {
      setActive(true);
      timeout = setTimeout(() => setActive(false), 520);
    }, interval);

    return () => {
      clearInterval(id);
      clearTimeout(timeout);
    };
  }, [auto, interval, reduce]);

  return (
    <span
      data-glitch={reduce ? undefined : text}
      data-glitch-active={active ? "true" : "false"}
      className={cn("relative inline-block", className)}
    >
      {text}
    </span>
  );
}
