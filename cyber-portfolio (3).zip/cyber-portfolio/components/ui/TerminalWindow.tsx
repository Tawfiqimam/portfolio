import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type TerminalWindowProps = {
  title?: string;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  /** Right-hand status pill in the title bar. */
  status?: string;
};

/**
 * The shared terminal chrome: title bar, three lamps, hairline, body.
 * Purely presentational so it can wrap static text, typed output, or the
 * fully interactive shell without duplicating the frame.
 */
export default function TerminalWindow({
  title = "bash",
  children,
  className,
  bodyClassName,
  status,
}: TerminalWindowProps) {
  return (
    <div
      className={cn(
        "glass clip-corner overflow-hidden shadow-lift",
        "ring-1 ring-matrix/10",
        className,
      )}
    >
      {/* Title bar */}
      <div className="flex items-center gap-3 border-b border-line bg-black/50 px-4 py-2.5">
        <div className="flex items-center gap-1.5" aria-hidden="true">
          <span className="size-2.5 rounded-full bg-critical/70" />
          <span className="size-2.5 rounded-full bg-medium/70" />
          <span className="size-2.5 rounded-full bg-matrix/80" />
        </div>

        <p className="truncate font-mono text-xs text-slate">{title}</p>

        {status && (
          <span className="ml-auto flex shrink-0 items-center gap-1.5 font-mono text-[0.65rem] tracking-widest text-matrix uppercase">
            <span className="relative flex size-1.5">
              <span className="animate-pulse-ring absolute inset-0 rounded-full bg-matrix" />
              <span className="relative size-1.5 rounded-full bg-matrix" />
            </span>
            {status}
          </span>
        )}
      </div>

      <div
        className={cn(
          "scanlines relative px-4 py-4 font-mono text-sm sm:px-5 sm:py-5",
          bodyClassName,
        )}
      >
        {children}
      </div>
    </div>
  );
}
