"use client";

import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "framer-motion";
import type { TerminalLine } from "@/lib/site";
import { site } from "@/lib/site";
import { cn } from "@/lib/utils";

type TypeLinesProps = {
  lines: TerminalLine[];
  /** ms per character for command lines. Output lines appear whole. */
  speed?: number;
  /** Pause between lines, in ms. */
  linePause?: number;
  className?: string;
  /** Loop the sequence from the start once finished. */
  loop?: boolean;
};

const PROMPT = `root@${site.handle}:~$`;

/**
 * Types command lines character-by-character and prints output lines whole,
 * which is how a real shell behaves. Under reduced motion the entire
 * transcript renders immediately in its final state.
 *
 * The animation is driven by a single timeout chain rather than an interval
 * per line, so nothing keeps running after unmount.
 */
export default function TypeLines({
  lines,
  speed = 42,
  linePause = 420,
  className,
  loop = false,
}: TypeLinesProps) {
  const reduce = useReducedMotion();
  const [lineIndex, setLineIndex] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [done, setDone] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (reduce) return;

    const current = lines[lineIndex];

    // Sequence finished.
    if (!current) {
      if (loop) {
        timer.current = setTimeout(() => {
          setLineIndex(0);
          setCharCount(0);
          setDone(false);
        }, 2600);
      } else {
        setDone(true);
      }
      return () => {
        if (timer.current) clearTimeout(timer.current);
      };
    }

    // Output lines are not typed — they print in one go.
    if (current.type !== "command") {
      timer.current = setTimeout(() => {
        setLineIndex((i) => i + 1);
        setCharCount(0);
      }, linePause);
      return () => {
        if (timer.current) clearTimeout(timer.current);
      };
    }

    // Still typing this command.
    if (charCount < current.text.length) {
      timer.current = setTimeout(() => setCharCount((c) => c + 1), speed);
    } else {
      timer.current = setTimeout(() => {
        setLineIndex((i) => i + 1);
        setCharCount(0);
      }, linePause);
    }

    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [lines, lineIndex, charCount, speed, linePause, reduce, loop]);

  const visible = reduce ? lines : lines.slice(0, lineIndex + 1);

  return (
    /* The transcript is decorative repetition of copy that already exists in
       the heading, so it is hidden from assistive tech to avoid a
       character-by-character announcement storm. */
    <div className={cn("space-y-1.5", className)} aria-hidden="true">
      {visible.map((line, i) => {
        const isLast = i === visible.length - 1 && !reduce;
        const isCommand = line.type === "command";
        const text =
          isCommand && isLast && !done ? line.text.slice(0, charCount) : line.text;

        if (isCommand) {
          return (
            <p key={`${line.text}-${i}`} className="flex flex-wrap gap-x-2">
              <span className="text-matrix select-none">{PROMPT}</span>
              <span className="text-bone">
                {text}
                {isLast && !done && (
                  <span className="animate-caret ml-0.5 inline-block h-4 w-2 translate-y-0.5 bg-matrix" />
                )}
              </span>
            </p>
          );
        }

        return (
          <p
            key={`${line.text}-${i}`}
            className={cn(
              "pl-0",
              line.type === "success"
                ? "text-glow-soft font-medium text-matrix"
                : "text-ash",
            )}
          >
            {text}
          </p>
        );
      })}

      {/* Idle caret once the sequence has completed. */}
      {(done || reduce) && (
        <p className="flex gap-x-2">
          <span className="text-matrix select-none">{PROMPT}</span>
          <span className="animate-caret inline-block h-4 w-2 translate-y-0.5 bg-matrix" />
        </p>
      )}
    </div>
  );
}
