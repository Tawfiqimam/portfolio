import Link from "next/link";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "ghost";

type CyberButtonProps = {
  href: string;
  children: ReactNode;
  variant?: Variant;
  className?: string;
  /** Set for outbound links; adds rel and the new-tab affordance. */
  external?: boolean;
  "aria-label"?: string;
};

const base =
  "clip-corner group relative inline-flex min-h-12 cursor-pointer items-center justify-center gap-2.5 " +
  "px-6 font-mono text-sm font-medium tracking-wide " +
  "transition-[background-color,border-color,color,box-shadow] duration-200 ease-out " +
  "focus-visible:outline-2 focus-visible:outline-offset-3 focus-visible:outline-matrix";

const variants: Record<Variant, string> = {
  primary:
    "border border-matrix/60 bg-matrix/12 text-matrix hover:bg-matrix/22 hover:border-matrix hover:shadow-glow",
  ghost:
    "border border-line-bright bg-white/[0.02] text-bone hover:border-matrix/50 hover:bg-matrix/8 hover:text-matrix",
};

/**
 * The single CTA component. Both variants are ≥48px tall and keep a visible
 * focus ring, so the clipped-corner styling never costs keyboard usability.
 */
export default function CyberButton({
  href,
  children,
  variant = "primary",
  className,
  external = false,
  ...rest
}: CyberButtonProps) {
  const classes = cn(base, variants[variant], className);

  if (external) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={classes}
        {...rest}
      >
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={classes} {...rest}>
      {children}
    </Link>
  );
}
