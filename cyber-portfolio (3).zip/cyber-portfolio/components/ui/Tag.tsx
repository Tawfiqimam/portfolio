import { cn } from "@/lib/utils";

/**
 * Small technology / topic chip. `whitespace-nowrap` keeps two-word labels
 * from breaking mid-chip, and the parent is always a wrapping flex row.
 */
export default function Tag({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center border border-line-bright bg-white/[0.025] px-2 py-0.5",
        "font-mono text-[0.7rem] whitespace-nowrap text-ash",
        "transition-colors duration-200 group-hover:border-matrix/30 group-hover:text-matrix/90",
        className,
      )}
    >
      {children}
    </span>
  );
}
