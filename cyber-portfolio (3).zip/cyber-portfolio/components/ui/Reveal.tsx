"use client";

import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";
import { EASE_OUT_EXPO } from "@/lib/motion";

type Tag = "div" | "li" | "article" | "section" | "span";

type RevealProps = {
  children: ReactNode;
  /** Stagger offset in seconds when revealing a list. */
  delay?: number;
  /** Travel distance in px. Set to 0 for a pure fade. */
  y?: number;
  className?: string;
  /** Render as something other than a div, to keep list semantics valid. */
  as?: Tag;
};

/* Looking a motion component up by key yields a union of component types,
   which TypeScript cannot call directly. Every tag here accepts the same
   props we pass, so one narrow cast at the lookup is sound and keeps the
   call site fully typed. */
const tags = {
  div: motion.div,
  li: motion.li,
  article: motion.article,
  section: motion.section,
  span: motion.span,
} as const;

type MotionDiv = typeof motion.div;

/**
 * Scroll-triggered entrance. Fires once, never re-animates on scroll-back,
 * and collapses to a plain static element when reduced motion is requested —
 * the content is always in the DOM and always readable either way.
 */
export default function Reveal({
  children,
  delay = 0,
  y = 20,
  className,
  as = "div",
}: RevealProps) {
  const reduce = useReducedMotion();

  if (reduce) {
    const Static = as;
    return <Static className={className}>{children}</Static>;
  }

  const MotionTag = tags[as] as MotionDiv;

  return (
    <MotionTag
      className={className}
      data-reveal=""
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay, ease: EASE_OUT_EXPO }}
    >
      {children}
    </MotionTag>
  );
}
