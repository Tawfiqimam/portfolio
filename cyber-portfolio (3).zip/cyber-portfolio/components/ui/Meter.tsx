"use client";

import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";
import { EASE_OUT_EXPO } from "@/lib/motion";

type MeterProps = {
  /** 0–100 */
  value: number;
  label: string;
  /** Rendered to the right of the label. */
  note?: string;
  /** Stagger offset in seconds. */
  delay?: number;
  className?: string;
  /** Show the numeric value as text. Off by default to reduce noise. */
  showValue?: boolean;
};

/**
 * Animated proficiency bar. The fill grows on scroll-into-view by animating
 * `transform: scaleX` rather than `width`, so it never triggers layout.
 *
 * Exposed as a real progressbar with aria-valuenow, and the track is laid out
 * at full width from the first paint so there is zero layout shift.
 */
export default function Meter({
  value,
  label,
  note,
  delay = 0,
  className,
  showValue = false,
}: MeterProps) {
  const reduce = useReducedMotion();
  const clamped = Math.min(100, Math.max(0, value));

  return (
    <div className={cn("group/meter", className)}>
      {/* Label and note are stacked rather than placed on one row: at card
          width both wrap, and two wrapping columns read as noise. */}
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <span className="font-mono text-sm text-bone">{label}</span>
        {showValue && (
          <span className="font-mono text-xs tabular-nums text-matrix">
            {clamped}%
          </span>
        )}
      </div>

      <div
        role="progressbar"
        aria-label={`${label} proficiency`}
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
        className="relative h-1.5 w-full overflow-hidden rounded-full bg-surface-3"
      >
        <motion.div
          className="h-full origin-left rounded-full bg-linear-to-r from-matrix-deep via-matrix-dim to-matrix"
          style={{ width: `${clamped}%` }}
          initial={reduce ? { scaleX: 1 } : { scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 1.1, delay, ease: EASE_OUT_EXPO }
          }
        />
        {/* Leading glow, follows the fill edge. */}
        <motion.span
          aria-hidden="true"
          className="absolute top-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-matrix shadow-glow-sm"
          initial={reduce ? { left: `${clamped}%` } : { left: "0%" }}
          whileInView={{ left: `${clamped}%` }}
          viewport={{ once: true, margin: "-40px" }}
          transition={
            reduce
              ? { duration: 0 }
              : { duration: 1.1, delay, ease: EASE_OUT_EXPO }
          }
        />
      </div>

      {note && (
        <p className="mt-2 font-mono text-[0.68rem] leading-snug text-slate">
          {note}
        </p>
      )}
    </div>
  );
}
