import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import Reveal from "./Reveal";

type SectionShellProps = {
  id: string;
  /** Monospace eyebrow, rendered as `// 01 — label`. */
  index: string;
  eyebrow: string;
  title: ReactNode;
  description?: string;
  children: ReactNode;
  className?: string;
  /** Pulls the heading block to the centre, used for the closing sections. */
  centered?: boolean;
};

/**
 * Every section shares this frame: a numbered eyebrow, a display heading, an
 * optional lede, then content. Consistency here is what stops a page with
 * nine sections from reading as nine different websites.
 */
export default function SectionShell({
  id,
  index,
  eyebrow,
  title,
  description,
  children,
  className,
  centered = false,
}: SectionShellProps) {
  return (
    <section
      id={id}
      aria-labelledby={`${id}-heading`}
      className={cn("relative scroll-mt-24 py-20 sm:py-28 lg:py-32", className)}
    >
      <div className="mx-auto w-full max-w-7xl px-6 lg:px-10">
        <Reveal>
          <div
            className={cn(
              "mb-12 max-w-3xl sm:mb-16",
              centered && "mx-auto text-center",
            )}
          >
            <div
              className={cn(
                "mb-4 flex items-center gap-3",
                centered && "justify-center",
              )}
            >
              <span className="eyebrow tabular-nums">{index}</span>
              <span
                aria-hidden="true"
                className="h-px w-10 bg-linear-to-r from-matrix/70 to-transparent"
              />
              <span className="font-mono text-xs tracking-[0.22em] text-slate uppercase">
                {eyebrow}
              </span>
            </div>

            <h2
              id={`${id}-heading`}
              className="text-3xl sm:text-4xl lg:text-5xl"
            >
              {title}
            </h2>

            {description && (
              <p className="mt-5 max-w-2xl text-sm leading-relaxed text-ash sm:text-base">
                {description}
              </p>
            )}
          </div>
        </Reveal>

        {children}
      </div>
    </section>
  );
}
