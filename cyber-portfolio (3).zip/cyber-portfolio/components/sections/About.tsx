import { ShieldCheck } from "lucide-react";
import { about, site } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import TerminalWindow from "@/components/ui/TerminalWindow";
import Reveal from "@/components/ui/Reveal";

export default function About() {
  return (
    <SectionShell
      id="about"
      index="// 01"
      eyebrow="About"
      title={
        <>
          The person behind
          <br />
          the <span className="text-matrix">findings</span>.
        </>
      }
      description="Offensive security is only useful if someone can act on it. That constraint shapes how I test and how I write."
    >
      <div className="grid gap-10 lg:grid-cols-[1fr_0.85fr] lg:gap-14">
        {/* Prose */}
        <div className="space-y-5">
          {about.paragraphs.map((paragraph, i) => (
            <Reveal key={i} delay={i * 0.08}>
              <p className="text-sm leading-[1.75] text-ash sm:text-[0.95rem]">
                {paragraph}
              </p>
            </Reveal>
          ))}

          {/* Stats */}
          <Reveal delay={0.2}>
            <dl className="mt-10 grid grid-cols-2 gap-px overflow-hidden border border-line bg-line sm:grid-cols-4">
              {about.stats.map((stat) => (
                /* Labels wrap to different line counts, so the cell is a
                   column and the value is pushed to the bottom — otherwise
                   the four numbers sit on four different baselines. */
                <div
                  key={stat.label}
                  className="flex min-h-28 flex-col bg-abyss px-4 py-5 transition-colors duration-200 hover:bg-surface-2"
                >
                  <dt className="font-mono text-[0.65rem] leading-snug tracking-[0.12em] text-slate uppercase">
                    {stat.label}
                  </dt>
                  <dd className="text-glow-soft mt-auto pt-3 font-display text-2xl font-semibold text-matrix tabular-nums sm:text-3xl">
                    {stat.value}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        {/* Terminal profile */}
        <Reveal delay={0.12}>
          <div className="lg:sticky lg:top-28">
            <TerminalWindow
              title={`${site.handle} — profile`}
              status="verified"
              bodyClassName="space-y-4"
            >
              <p className="text-ash">
                <span className="text-matrix select-none">$</span> cat
                ./operator.json
              </p>

              <dl className="space-y-2.5 border-l border-line pl-4">
                {about.facts.map((fact) => (
                  <div
                    key={fact.key}
                    className="flex flex-wrap items-baseline gap-x-2 text-xs sm:text-sm"
                  >
                    <dt className="text-matrix-dim">{fact.key}:</dt>
                    <dd className="text-bone">{fact.value}</dd>
                  </div>
                ))}
              </dl>

              <div className="border-t border-line pt-4">
                <p className="flex items-start gap-2.5 text-xs leading-relaxed text-slate">
                  <ShieldCheck
                    className="mt-0.5 size-4 shrink-0 text-matrix"
                    aria-hidden="true"
                  />
                  <span>
                    Every engagement referenced on this site was performed
                    under written authorisation. Vulnerabilities are published
                    only after coordinated disclosure.
                  </span>
                </p>
              </div>
            </TerminalWindow>
          </div>
        </Reveal>
      </div>
    </SectionShell>
  );
}
