"use client";

import { useRef } from "react";
import {
  motion,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import { experience } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import Tag from "@/components/ui/Tag";

export default function Experience() {
  const trackRef = useRef<HTMLOListElement>(null);
  const reduce = useReducedMotion();

  /* Scroll-linked fill for the timeline rail. This reads scroll position to
     drive a transform — it does not hijack scrolling, and under reduced
     motion the rail is simply rendered full. */
  const { scrollYProgress } = useScroll({
    target: trackRef,
    offset: ["start 70%", "end 60%"],
  });

  const smooth = useSpring(scrollYProgress, {
    stiffness: 90,
    damping: 28,
    restDelta: 0.001,
  });

  const scaleY = useTransform(smooth, (value) => (reduce ? 1 : value));

  return (
    <SectionShell
      id="experience"
      index="// 06"
      eyebrow="Experience"
      title={
        <>
          Seven years, one <span className="text-matrix">trajectory</span>.
        </>
      }
      description="Defence first, then offence — which is still the reason my reports get read instead of filed."
    >
      {/* The rail lives beside the list, not inside it: an <ol> may only
          contain <li>, and a decorative div there is invalid HTML. */}
      <div className="relative">
        <div
          aria-hidden="true"
          data-decorative
          className="absolute top-2 bottom-2 left-[7px] w-px bg-line sm:left-[11px]"
        >
          <motion.div
            className="h-full w-full origin-top bg-linear-to-b from-matrix via-matrix-dim to-matrix-deep"
            style={{ scaleY }}
          />
        </div>

        <ol ref={trackRef} className="relative space-y-10 sm:space-y-12">
          {experience.map((role, i) => (
            <Reveal
              key={`${role.org}-${role.period}`}
              as="li"
              delay={Math.min(i * 0.06, 0.24)}
              className="relative pl-9 sm:pl-14"
            >
              {/* Node */}
              <span
                aria-hidden="true"
                className="absolute top-1.5 left-0 flex size-4 items-center justify-center sm:size-6"
              >
                <span className="absolute inset-0 rounded-full border border-matrix/35 bg-void" />
                {role.current && (
                  <span className="animate-pulse-ring absolute inset-0 rounded-full bg-matrix/50" />
                )}
                <span
                  className={
                    role.current
                      ? "relative size-2 rounded-full bg-matrix shadow-glow-sm"
                      : "relative size-1.5 rounded-full bg-matrix-deep"
                  }
                />
              </span>

              <article className="glass clip-corner p-5 transition-colors duration-300 hover:border-matrix/30 sm:p-6">
                <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2">
                  <div className="min-w-0">
                    <h3 className="font-display text-lg font-semibold text-bone sm:text-xl">
                      {role.title}
                    </h3>
                    <p className="mt-1 font-mono text-[0.78rem] text-matrix">
                      {role.org}
                    </p>
                  </div>

                  <p className="flex shrink-0 items-center gap-2 font-mono text-[0.72rem] text-slate tabular-nums">
                    {role.period}
                    {role.current && (
                      <span className="border border-matrix/40 bg-matrix/10 px-1.5 py-px text-[0.6rem] tracking-[0.12em] text-matrix uppercase">
                        now
                      </span>
                    )}
                  </p>
                </div>

                <p className="mt-4 max-w-[68ch] text-[0.85rem] leading-relaxed text-ash">
                  {role.summary}
                </p>

                <ul className="mt-5 max-w-[72ch] space-y-2.5">
                  {role.highlights.map((highlight) => (
                    <li
                      key={highlight}
                      className="flex gap-3 text-[0.8rem] leading-relaxed text-ash"
                    >
                      <span
                        aria-hidden="true"
                        className="mt-2 size-1 shrink-0 bg-matrix/70"
                      />
                      {highlight}
                    </li>
                  ))}
                </ul>

                <ul className="group mt-5 flex flex-wrap gap-1.5 border-t border-line pt-5">
                  {role.tags.map((tag) => (
                    <li key={tag}>
                      <Tag>{tag}</Tag>
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </ol>
      </div>
    </SectionShell>
  );
}
