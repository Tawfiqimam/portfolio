import {
  Github,
  Globe,
  Linkedin,
  Mail,
  Twitter,
  type LucideIcon,
} from "lucide-react";
import { site, socials, type SocialLink } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import CyberButton from "@/components/ui/CyberButton";
import InteractiveTerminal from "@/components/interactive/InteractiveTerminal";

const icons: Record<SocialLink["icon"], LucideIcon> = {
  github: Github,
  linkedin: Linkedin,
  twitter: Twitter,
  mail: Mail,
  globe: Globe,
};

export default function Contact() {
  return (
    <SectionShell
      id="contact"
      index="// 08"
      eyebrow="Contact"
      title={
        <>
          Open a <span className="text-matrix">channel</span>.
        </>
      }
      description="Available for penetration testing, red team engagements, security research collaboration and responsible disclosure. Encrypted mail welcome."
    >
      <div className="grid gap-8 lg:grid-cols-[1fr_1fr] lg:gap-10">
        {/* Interactive shell */}
        <Reveal>
          <InteractiveTerminal />
        </Reveal>

        {/* Channels */}
        <Reveal delay={0.1} className="flex flex-col gap-4">
          {/* Primary */}
          <div className="glass clip-corner p-6">
            <p className="font-mono text-[0.65rem] tracking-[0.2em] text-slate uppercase">
              primary channel
            </p>

            <a
              href={`mailto:${site.email}`}
              className="mt-2 inline-block font-display text-xl font-semibold break-all text-bone transition-colors duration-200 hover:text-matrix sm:text-2xl"
            >
              {site.email}
            </a>

            <p className="mt-4 text-[0.82rem] leading-relaxed text-ash">
              For security reports, include a proof-of-concept and the affected
              version. For work enquiries, a short description of the scope is
              enough to start. I reply within 48 hours.
            </p>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <CyberButton href={`mailto:${site.email}`} variant="primary">
                <Mail className="size-4" aria-hidden="true" />
                Send a message
              </CyberButton>
              <CyberButton href={site.resumeUrl} variant="ghost" external>
                Download CV
              </CyberButton>
            </div>
          </div>

          {/* Socials */}
          <ul className="grid gap-px overflow-hidden border border-line bg-line sm:grid-cols-2">
            {socials.map((link) => {
              const Icon = icons[link.icon];
              const isMail = link.icon === "mail";

              return (
                <li key={link.label}>
                  <a
                    href={link.href}
                    target={isMail ? undefined : "_blank"}
                    rel={isMail ? undefined : "noopener noreferrer"}
                    className="group flex min-h-16 items-center gap-3 bg-abyss px-4 py-4 transition-colors duration-200 hover:bg-surface-2"
                  >
                    <Icon
                      className="size-4 shrink-0 text-slate transition-colors duration-200 group-hover:text-matrix"
                      aria-hidden="true"
                    />
                    <div className="min-w-0">
                      <p className="font-mono text-[0.78rem] text-bone transition-colors duration-200 group-hover:text-matrix">
                        {link.label}
                      </p>
                      <p className="truncate font-mono text-[0.68rem] text-slate">
                        {link.handle}
                      </p>
                    </div>
                  </a>
                </li>
              );
            })}
          </ul>

        </Reveal>
      </div>
    </SectionShell>
  );
}
