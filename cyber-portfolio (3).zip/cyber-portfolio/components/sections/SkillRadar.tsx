"use client";

import { motion, useReducedMotion } from "framer-motion";
import { skillGroups } from "@/lib/site";
import { EASE_OUT_EXPO } from "@/lib/motion";

/* One axis per group, scored as the mean of that group's skills. */
const axes = skillGroups.flatMap((group) =>
  group.skills.map((skill) => ({ label: skill.name, value: skill.level })),
);

const SIZE = 320;
const CENTER = SIZE / 2;
const RADIUS = 118;
const RINGS = 4;

function pointAt(index: number, total: number, ratio: number) {
  /* Start at 12 o'clock and go clockwise. */
  const angle = (Math.PI * 2 * index) / total - Math.PI / 2;
  return {
    x: CENTER + Math.cos(angle) * RADIUS * ratio,
    y: CENTER + Math.sin(angle) * RADIUS * ratio,
  };
}

/**
 * Radar chart of competency scores.
 *
 * The SVG is labelled and described, but the authoritative, screen-reader
 * friendly version of this data is the meter list beside it — so the chart is
 * presentational reinforcement, never the only way to read the numbers.
 * Nothing here is conveyed by colour alone.
 */
export default function SkillRadar() {
  const reduce = useReducedMotion();
  const total = axes.length;

  const polygon = axes
    .map((axis, i) => {
      const { x, y } = pointAt(i, total, axis.value / 100);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <div className="relative mx-auto w-full max-w-[22rem]">
      <svg
        viewBox={`0 0 ${SIZE} ${SIZE}`}
        role="img"
        aria-label={`Competency radar across ${total} disciplines. Exact values are listed in the skill breakdown beside this chart.`}
        className="w-full overflow-visible"
      >
        {/* Concentric rings */}
        {Array.from({ length: RINGS }, (_, ring) => {
          const ratio = (ring + 1) / RINGS;
          const points = Array.from({ length: total }, (_, i) => {
            const { x, y } = pointAt(i, total, ratio);
            return `${x.toFixed(1)},${y.toFixed(1)}`;
          }).join(" ");

          return (
            <polygon
              key={ring}
              points={points}
              fill="none"
              stroke="var(--color-line-bright)"
              strokeWidth={1}
              opacity={0.65}
            />
          );
        })}

        {/* Spokes */}
        {axes.map((axis, i) => {
          const { x, y } = pointAt(i, total, 1);
          return (
            <line
              key={axis.label}
              x1={CENTER}
              y1={CENTER}
              x2={x}
              y2={y}
              stroke="var(--color-line-bright)"
              strokeWidth={1}
              opacity={0.5}
            />
          );
        })}

        {/* Data polygon — scales up from the centre on view. */}
        <motion.polygon
          points={polygon}
          fill="rgba(0, 255, 65, 0.14)"
          stroke="var(--color-matrix)"
          strokeWidth={1.75}
          strokeLinejoin="round"
          style={{ transformOrigin: `${CENTER}px ${CENTER}px` }}
          initial={reduce ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 1 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={
            reduce ? { duration: 0 } : { duration: 1.1, ease: EASE_OUT_EXPO }
          }
        />

        {/* Vertices */}
        {axes.map((axis, i) => {
          const { x, y } = pointAt(i, total, axis.value / 100);
          return (
            <motion.circle
              key={axis.label}
              cx={x}
              cy={y}
              r={2.75}
              fill="var(--color-matrix)"
              initial={reduce ? { opacity: 1 } : { opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: reduce ? 0 : 0.9 + i * 0.04, duration: 0.3 }}
            />
          );
        })}

        <circle cx={CENTER} cy={CENTER} r={2} fill="var(--color-matrix-deep)" />
      </svg>

      {/* Caption */}
      <p className="mt-4 text-center font-mono text-[0.65rem] tracking-[0.18em] text-slate uppercase">
        competency distribution — {total} disciplines
      </p>
    </div>
  );
}
