import {
  Crosshair,
  Globe,
  Network,
  Search,
  Terminal,
  Users,
  type LucideIcon,
} from "lucide-react";
import { languages, skillGroups, type SkillGroup } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import Meter from "@/components/ui/Meter";
import SkillRadar from "./SkillRadar";

const icons: Record<SkillGroup["icon"], LucideIcon> = {
  crosshair: Crosshair,
  globe: Globe,
  network: Network,
  search: Search,
  users: Users,
  terminal: Terminal,
};

export default function Skills() {
  return (
    <SectionShell
      id="skills"
      index="// 02"
      eyebrow="Skills & Expertise"
      title={
        <>
          Where I&apos;m <span className="text-matrix">dangerous</span>.
        </>
      }
      description="Four overlapping disciplines. The interesting work almost always happens where two of them meet."
    >
      <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        {/* Radar */}
        <Reveal className="lg:sticky lg:top-28 lg:self-start">
          <div className="glass clip-corner p-6 sm:p-8">
            <SkillRadar />
          </div>
        </Reveal>

        {/* Groups */}
        <div className="grid gap-5 sm:grid-cols-2">
          {skillGroups.map((group, groupIndex) => {
            const Icon = icons[group.icon];

            return (
              <Reveal
                key={group.id}
                as="article"
                delay={groupIndex * 0.07}
                className="group glass clip-corner flex flex-col p-5 transition-colors duration-300 hover:border-matrix/30 sm:p-6"
              >
                <div className="mb-4 flex items-start gap-3">
                  <span className="flex size-9 shrink-0 items-center justify-center border border-matrix/30 bg-matrix/8 text-matrix transition-colors duration-300 group-hover:bg-matrix/15">
                    <Icon className="size-4.5" aria-hidden="true" />
                  </span>
                  <div className="min-w-0">
                    <h3 className="font-display text-base font-semibold text-bone">
                      {group.title}
                    </h3>
                    <p className="mt-1 font-mono text-[0.7rem] leading-snug text-slate">
                      {group.blurb}
                    </p>
                  </div>
                </div>

                <div className="mt-auto space-y-4 border-t border-line pt-5">
                  {group.skills.map((skill, i) => (
                    <Meter
                      key={skill.name}
                      label={skill.name}
                      note={skill.note}
                      value={skill.level}
                      delay={i * 0.1}
                    />
                  ))}
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>

      {/* Languages — a compact strip rather than four more meters, since these
          support the security work rather than standing on their own. */}
      <Reveal delay={0.1}>
        <div className="mt-12 border-t border-line pt-8">
          <h3 className="mb-5 font-mono text-[0.7rem] tracking-[0.2em] text-matrix uppercase">
            Languages & Scripting
          </h3>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
            {languages.map((lang) => (
              <li key={lang.name}>
                <div className="mb-1.5 flex items-baseline justify-between gap-2">
                  <span className="font-mono text-sm text-bone">
                    {lang.name}
                  </span>
                  <span className="font-mono text-[0.7rem] text-slate tabular-nums">
                    {lang.level}%
                  </span>
                </div>
                <div
                  role="progressbar"
                  aria-label={`${lang.name} proficiency`}
                  aria-valuenow={lang.level}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  className="h-1 w-full overflow-hidden rounded-full bg-surface-3"
                >
                  <span
                    className="block h-full rounded-full bg-matrix/70"
                    style={{ width: `${lang.level}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </div>
      </Reveal>
    </SectionShell>
  );
}
