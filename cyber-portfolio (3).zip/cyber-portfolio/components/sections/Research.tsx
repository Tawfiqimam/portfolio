import { ArrowUpRight, Clock, Trophy } from "lucide-react";
import { writeups, type Writeup } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import SeverityBadge from "@/components/ui/SeverityBadge";
import { cn } from "@/lib/utils";

const kindStyles: Record<Writeup["kind"], string> = {
  Disclosure: "border-high/40 text-high",
  "Hall of Fame": "border-medium/40 text-medium",
  Analysis: "border-low/40 text-low",
  Writeup: "border-matrix/40 text-matrix",
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-GB", {
    year: "numeric",
    month: "short",
  });
}

export default function Research() {
  return (
    <SectionShell
      id="research"
      index="// 03"
      eyebrow="Research & Disclosures"
      title={
        <>
          Reported, validated, <span className="text-matrix">recognised</span>.
        </>
      }
      description="A selection from 300+ reports, 100+ Hall of Fame recognitions and 50+ Critical severity findings. Everything here went through official disclosure channels, and nothing was published before the program allowed it."
    >
      <ul className="divide-y divide-line border-y border-line">
        {writeups.map((entry, i) => {
          /* Only make the row a link when there is somewhere to send people. */
          const Wrapper = entry.href ? "a" : "div";

          return (
            <Reveal key={entry.id} as="li" delay={Math.min(i * 0.05, 0.25)}>
              <Wrapper
                {...(entry.href
                  ? {
                      href: entry.href,
                      target: "_blank",
                      rel: "noopener noreferrer",
                    }
                  : {})}
                className={cn(
                  "group relative grid grid-cols-1 gap-x-6 gap-y-3 px-1 py-6 sm:grid-cols-[auto_1fr_auto] sm:items-start sm:px-4",
                  entry.href &&
                    "transition-colors duration-300 hover:bg-white/[0.015]",
                )}
              >
                {/* Meta column */}
                <div className="flex flex-wrap items-center gap-2 sm:w-36 sm:flex-col sm:items-start sm:gap-2.5">
                  <span
                    className={cn(
                      "clip-corner-sm inline-flex items-center gap-1.5 border px-2 py-0.5",
                      "font-mono text-[0.62rem] tracking-[0.14em] uppercase",
                      kindStyles[entry.kind],
                    )}
                  >
                    {entry.kind === "Hall of Fame" && (
                      <Trophy className="size-3" aria-hidden="true" />
                    )}
                    {entry.kind}
                  </span>

                  {entry.program && (
                    <span
                      className={cn(
                        "font-display text-sm font-semibold",
                        entry.program === "Undisclosed"
                          ? "text-slate italic"
                          : "text-bone",
                      )}
                    >
                      {entry.program}
                    </span>
                  )}

                  {entry.date && (
                    <time
                      dateTime={entry.date}
                      className="font-mono text-[0.7rem] text-slate tabular-nums"
                    >
                      {formatDate(entry.date)}
                    </time>
                  )}
                </div>

                {/* Body */}
                <div className="min-w-0">
                  <h3
                    className={cn(
                      "font-display text-base leading-snug font-medium text-bone sm:text-lg",
                      entry.href &&
                        "transition-colors duration-200 group-hover:text-matrix",
                    )}
                  >
                    {entry.title}
                  </h3>

                  <p className="mt-2 max-w-2xl text-[0.82rem] leading-relaxed text-ash">
                    {entry.excerpt}
                  </p>

                  {(entry.cve ||
                    entry.severity ||
                    entry.cvss ||
                    entry.category ||
                    entry.readTime) && (
                    <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
                      {entry.cve && (
                        <span className="font-mono text-[0.7rem] text-critical">
                          {entry.cve}
                        </span>
                      )}
                      {entry.severity && <SeverityBadge level={entry.severity} />}

                      {/* The score is spelled out as "CVSS 9.4" rather than a
                          bare number, so it reads correctly out of context. */}
                      {entry.cvss !== undefined && (
                        <span className="clip-corner-sm inline-flex items-center gap-1.5 border border-line-bright bg-white/[0.025] px-2 py-0.5 font-mono text-[0.65rem] text-bone">
                          <span className="text-slate">CVSS</span>
                          <span className="tabular-nums">
                            {entry.cvss.toFixed(1)}
                          </span>
                        </span>
                      )}

                      {entry.category && (
                        <span className="font-mono text-[0.7rem] text-slate">
                          {entry.category}
                        </span>
                      )}
                      {entry.readTime && (
                        <span className="inline-flex items-center gap-1.5 font-mono text-[0.7rem] text-slate">
                          <Clock className="size-3" aria-hidden="true" />
                          {entry.readTime}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Affordance — only when the row actually goes somewhere */}
                {entry.href && (
                  <>
                    <span
                      aria-hidden="true"
                      className="hidden size-10 shrink-0 items-center justify-center border border-line text-slate transition-all duration-300 group-hover:border-matrix/50 group-hover:text-matrix sm:flex"
                    >
                      <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </span>
                    <span className="sr-only">Read: {entry.title}</span>
                  </>
                )}
              </Wrapper>
            </Reveal>
          );
        })}
      </ul>

      <Reveal delay={0.15}>
        <p className="mt-8 font-mono text-xs leading-relaxed text-slate">
          <span className="text-matrix-dim">$</span> All findings were reported
          through official disclosure channels and are published only with the
          program&apos;s permission. Technical detail is withheld where an
          embargo still applies.
        </p>
      </Reveal>
    </SectionShell>
  );
}
