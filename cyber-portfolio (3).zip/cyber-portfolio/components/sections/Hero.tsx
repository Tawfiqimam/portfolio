"use client";

import Image from "next/image";
import { motion, useReducedMotion, type MotionProps } from "framer-motion";
import { ArrowDown, ArrowUpRight, MapPin, Terminal as TerminalIcon } from "lucide-react";
import { heroTerminal, site } from "@/lib/site";
import MatrixRain from "@/components/background/MatrixRain";
import CyberGrid from "@/components/background/CyberGrid";
import TerminalWindow from "@/components/ui/TerminalWindow";
import TypeLines from "@/components/ui/TypeLines";
import CyberButton from "@/components/ui/CyberButton";
import GlitchText from "@/components/ui/GlitchText";
import { hero } from "@/lib/motion";

export default function Hero() {
  const reduce = useReducedMotion();

  /* One shared transition so the hero reads as a single choreographed
     entrance rather than five unrelated animations. Typed as MotionProps so
     the empty reduced-motion branch stays assignable. */
  const rise = (delay: number): MotionProps =>
    reduce ? {} : {
      initial: { opacity: 0, y: 24 },
      animate: { opacity: 1, y: 0 },
      transition: hero(delay),
    };

  return (
    <section
      id="top"
      aria-labelledby="hero-heading"
      className="relative flex min-h-dvh items-center overflow-hidden pt-24 pb-20 lg:pt-28"
    >
      {/* Background stack: rain under grid under vignette. */}
      <div className="absolute inset-0 -z-10">
        <MatrixRain className="opacity-[0.42]" />
        <CyberGrid />
      </div>

      <div className="mx-auto grid w-full max-w-7xl grid-cols-1 items-center gap-14 px-6 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16 lg:px-10">
        {/* ---------------------------------------------------------------- */}
        {/* Left column                                                      */}
        {/* ---------------------------------------------------------------- */}
        <div>
          {/* Availability chip */}
          <motion.div
            {...rise(0)}
            className="mb-7 inline-flex items-center gap-2.5 border border-matrix/25 bg-matrix/[0.07] px-3 py-1.5"
          >
            <span className="relative flex size-1.5">
              <span className="animate-pulse-ring absolute inset-0 rounded-full bg-matrix" />
              <span className="relative size-1.5 rounded-full bg-matrix" />
            </span>
            <span className="font-mono text-[0.7rem] tracking-[0.14em] text-matrix uppercase">
              {site.availability}
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            id="hero-heading"
            {...rise(0.08)}
            className="text-[clamp(2.25rem,6.2vw,4.5rem)] leading-[1.02] font-semibold tracking-[-0.03em]"
          >
            <span className="block text-bone">
              <GlitchText text={site.headline[0]} auto />
            </span>
            <span className="text-glow-soft block text-matrix">
              {site.headline[1]}
            </span>
          </motion.h1>

          {/* Roles */}
          <motion.p
            {...rise(0.16)}
            className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-1.5 font-mono text-sm text-ash sm:text-base"
          >
            {site.roles.map((role, i) => (
              <span key={role} className="flex items-center gap-3">
                {i > 0 && (
                  <span aria-hidden="true" className="text-matrix-dim">
                    |
                  </span>
                )}
                {role}
              </span>
            ))}
          </motion.p>

          {/* Terminal */}
          <motion.div {...rise(0.24)} className="mt-9 max-w-xl">
            <TerminalWindow
              title={`root@${site.handle}: ~`}
              status="live"
              bodyClassName="min-h-[8.5rem]"
            >
              <TypeLines lines={heroTerminal} loop />
            </TerminalWindow>
          </motion.div>

          {/* CTAs */}
          <motion.div
            {...rise(0.32)}
            className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center"
          >
            <CyberButton href="#research" variant="primary">
              <TerminalIcon className="size-4" aria-hidden="true" />
              Explore My Work
            </CyberButton>

            <CyberButton href="#contact" variant="ghost">
              Let&apos;s Connect
              <ArrowUpRight
                className="size-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                aria-hidden="true"
              />
            </CyberButton>
          </motion.div>

          {/* Meta row */}
          <motion.div
            {...rise(0.4)}
            className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 font-mono text-xs text-slate"
          >
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="size-3.5" aria-hidden="true" />
              {site.location}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span aria-hidden="true" className="text-matrix-dim">
                ◆
              </span>
              Authorised engagements only
            </span>
          </motion.div>
        </div>

        {/* ---------------------------------------------------------------- */}
        {/* Right column — portrait                                          */}
        {/* ---------------------------------------------------------------- */}
        <motion.div
          {...rise(0.2)}
          className="relative mx-auto w-full max-w-sm lg:max-w-none"
        >
          <div className="relative aspect-4/5 w-full">
            {/* Corner brackets */}
            {(
              [
                "top-0 left-0 border-t-2 border-l-2",
                "top-0 right-0 border-t-2 border-r-2",
                "bottom-0 left-0 border-b-2 border-l-2",
                "bottom-0 right-0 border-b-2 border-r-2",
              ] as const
            ).map((pos) => (
              <span
                key={pos}
                aria-hidden="true"
                data-decorative
                className={`absolute z-20 size-10 border-matrix/60 ${pos}`}
              />
            ))}

            {/* Frame */}
            <div className="glass relative size-full overflow-hidden">
              {/*
                PROFILE IMAGE PLACEHOLDER
                Drop a square-ish portrait at public/profile.jpg and this
                renders it. Until then the fallback HUD below shows through.
                `priority` is set because this is above the fold.
              */}
              <Image
                src={site.profileImage}
                alt={`${site.name}, ${site.role}`}
                fill
                priority
                sizes="(max-width: 1024px) 384px, 480px"
                className="object-cover opacity-90 brightness-110 contrast-110 grayscale"
              />

              {/* Green duotone wash over the portrait */}
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-linear-to-tr from-matrix/35 via-matrix/10 to-emerald/20 mix-blend-color"
              />

              {/*
                Backdrop, behind the portrait.
                An opaque JPG simply covers this. A transparent PNG cutout
                sits on top of it, so the subject reads as deliberately
                placed rather than as a broken image.
              */}
              <div
                aria-hidden="true"
                className="absolute inset-0 -z-10 bg-surface"
              >
                <div className="cyber-grid absolute inset-0 opacity-60" />

                {/* Glow rising from where the subject stands */}
                <div className="absolute inset-x-0 bottom-0 h-3/5 bg-[radial-gradient(ellipse_70%_90%_at_50%_100%,rgba(0,255,65,0.22),transparent_70%)]" />

                {/* Horizon line, roughly at shoulder height */}
                <div className="absolute inset-x-0 top-[38%] h-px bg-linear-to-r from-transparent via-matrix/30 to-transparent" />

                {/* Vignette so the edges never compete with the subject */}
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_45%,transparent_30%,rgba(5,5,5,0.6)_100%)]" />
              </div>

              <div className="scanlines absolute inset-0 opacity-80" />

              {/* Scanning line travelling down the portrait */}
              {!reduce && (
                <motion.div
                  aria-hidden="true"
                  data-decorative
                  className="absolute inset-x-0 h-16 bg-linear-to-b from-transparent via-matrix/22 to-transparent"
                  animate={{ y: ["-20%", "520%"] }}
                  transition={{
                    duration: 4.2,
                    repeat: Infinity,
                    ease: "linear",
                    repeatDelay: 1.4,
                  }}
                />
              )}

              {/* HUD readout, bottom-left */}
              <div className="absolute bottom-0 left-0 w-full border-t border-line bg-void/75 px-4 py-3 backdrop-blur-sm">
                <div className="flex items-end justify-between gap-3 font-mono">
                  <div>
                    <p className="text-[0.6rem] tracking-[0.2em] text-slate uppercase">
                      operator
                    </p>
                    <p className="text-sm text-bone">{site.name}</p>
                  </div>
                  <p className="text-right text-[0.6rem] leading-relaxed text-matrix">
                    CLR: PUBLIC
                    <br />
                    ID: 0x7F4A
                  </p>
                </div>
              </div>
            </div>

            {/* Floating label */}
            <div className="absolute -top-3 -right-3 z-20 hidden border border-matrix/40 bg-void px-2.5 py-1 font-mono text-[0.6rem] tracking-[0.2em] text-matrix uppercase sm:block">
              {site.tagline}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.a
        href="#about"
        aria-label="Scroll to the About section"
        initial={reduce ? undefined : { opacity: 0 }}
        animate={reduce ? undefined : { opacity: 1 }}
        transition={{ delay: 1.1, duration: 0.6 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 font-mono text-[0.65rem] tracking-[0.2em] text-slate uppercase transition-colors duration-200 hover:text-matrix lg:flex"
      >
        scroll
        <motion.span
          animate={reduce ? undefined : { y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <ArrowDown className="size-4" aria-hidden="true" />
        </motion.span>
      </motion.a>
    </section>
  );
}
