import { BadgeCheck, GraduationCap, LoaderCircle } from "lucide-react";
import { education } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import { cn } from "@/lib/utils";

export default function Education() {
  return (
    <SectionShell
      id="education"
      index="// 05"
      eyebrow="Education"
      title={
        <>
          Where the <span className="text-matrix">foundation</span> came from.
        </>
      }
      description="Formal study in computer science and networking, running alongside the independent research."
    >
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {education.map((item, i) => {
          const inProgress = item.status === "In Progress";
          const StatusIcon = inProgress ? LoaderCircle : BadgeCheck;

          return (
            <Reveal
              key={item.abbr + item.institution}
              as="li"
              delay={Math.min(i * 0.06, 0.3)}
              className="h-full"
            >
              <article
                className={cn(
                  "group glass clip-corner relative flex h-full flex-col p-5",
                  "transition-colors duration-300 hover:border-matrix/35",
                  inProgress && "border-dashed",
                )}
              >
                <div className="mb-4 flex items-start justify-between gap-3">
                  <span
                    className={cn(
                      "flex size-10 shrink-0 items-center justify-center border transition-colors duration-300",
                      inProgress
                        ? "border-medium/30 bg-medium/8 text-medium"
                        : "border-matrix/30 bg-matrix/8 text-matrix group-hover:bg-matrix/15",
                    )}
                  >
                    <GraduationCap className="size-5" aria-hidden="true" />
                  </span>

                  <span
                    className={cn(
                      "inline-flex items-center gap-1.5 font-mono text-[0.62rem] tracking-[0.14em] uppercase",
                      inProgress ? "text-medium" : "text-matrix",
                    )}
                  >
                    <StatusIcon className="size-3" aria-hidden="true" />
                    {item.status}
                  </span>
                </div>

                <p className="font-display text-2xl leading-none font-semibold tracking-tight text-bone">
                  {item.abbr}
                </p>

                <h3 className="mt-2 font-mono text-[0.82rem] leading-snug font-normal text-ash">
                  {item.qualification}
                </h3>

                <p className="mt-3 font-mono text-[0.72rem] leading-relaxed text-slate">
                  {item.blurb}
                </p>

                <dl className="mt-auto flex items-end justify-between gap-3 border-t border-line pt-4 font-mono text-[0.7rem]">
                  <div className="min-w-0">
                    <dt className="sr-only">Institution</dt>
                    <dd className="text-ash">{item.institution}</dd>
                  </div>
                  <div className="shrink-0 text-right">
                    <dt className="sr-only">Period</dt>
                    <dd className="text-slate tabular-nums">{item.period}</dd>
                  </div>
                </dl>
              </article>
            </Reveal>
          );
        })}
      </ul>
    </SectionShell>
  );
}
