"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, FileText, FolderOpen, Github, Star } from "lucide-react";
import {
  projectCategories,
  projects,
  type ProjectCategory,
} from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import Tag from "@/components/ui/Tag";
import SeverityBadge from "@/components/ui/SeverityBadge";
import { cn } from "@/lib/utils";
import { EASE_OUT_EXPO } from "@/lib/motion";

export default function Projects() {
  const [filter, setFilter] = useState<ProjectCategory>("All");
  const reduce = useReducedMotion();

  const visible = useMemo(
    () =>
      filter === "All"
        ? projects
        : projects.filter((project) => project.category === filter),
    [filter],
  );

  /* Counts are derived, so a category chip can never claim results it has not
     got — and the "0" state is reachable and designed for. */
  const counts = useMemo(() => {
    const map = new Map<ProjectCategory, number>([["All", projects.length]]);
    projects.forEach((project) => {
      map.set(project.category, (map.get(project.category) ?? 0) + 1);
    });
    return map;
  }, []);

  return (
    <SectionShell
      id="projects"
      index="// 04"
      eyebrow="Projects & Tooling"
      title={
        <>
          Selected <span className="text-matrix">work</span>.
        </>
      }
      description="The tooling I built because the off-the-shelf chain was too slow, and the challenges I solve to keep the manual side sharp."
    >
      {/* Filter bar */}
      <Reveal>
        <div
          role="group"
          aria-label="Filter projects by category"
          className="mb-10 flex flex-wrap gap-2"
        >
          {projectCategories.map((category) => {
            const isActive = filter === category;
            return (
              <button
                key={category}
                type="button"
                onClick={() => setFilter(category)}
                aria-pressed={isActive}
                className={cn(
                  "clip-corner-sm inline-flex min-h-11 cursor-pointer items-center gap-2 border px-4",
                  "font-mono text-xs tracking-wide transition-colors duration-200",
                  isActive
                    ? "border-matrix/60 bg-matrix/15 text-matrix"
                    : "border-line-bright bg-white/[0.02] text-ash hover:border-matrix/35 hover:text-bone",
                )}
              >
                {category}
                <span
                  className={cn(
                    "tabular-nums",
                    isActive ? "text-matrix/70" : "text-slate",
                  )}
                >
                  {counts.get(category) ?? 0}
                </span>
              </button>
            );
          })}
        </div>
      </Reveal>

      {/* Result count, announced politely on change */}
      <p aria-live="polite" className="sr-only">
        {visible.length} {visible.length === 1 ? "project" : "projects"} shown
        {filter !== "All" ? ` in ${filter}` : ""}.
      </p>

      {/* Grid */}
      <motion.div
        layout={!reduce}
        className="grid auto-rows-fr gap-5 sm:grid-cols-2 lg:grid-cols-3"
      >
        <AnimatePresence mode="popLayout" initial={false}>
          {visible.map((project) => (
            <motion.article
              key={project.id}
              layout={!reduce}
              initial={reduce ? false : { opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={reduce ? undefined : { opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.32, ease: EASE_OUT_EXPO }}
              className={cn(
                "group glass clip-corner relative flex flex-col p-5 sm:p-6",
                "transition-colors duration-300 hover:border-matrix/35",
                project.featured && "lg:col-span-1",
              )}
            >
              {/* Hover glow, contained so it never bleeds onto neighbours */}
              <span
                aria-hidden="true"
                data-decorative
                className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                style={{
                  background:
                    "radial-gradient(400px circle at 50% 0%, rgba(0,255,65,0.07), transparent 70%)",
                }}
              />

              {/* Header */}
              <div className="relative mb-3 flex items-start justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[0.65rem] tracking-[0.16em] text-matrix uppercase">
                    {project.category}
                  </span>
                  {project.featured && (
                    <Star
                      className="size-3 text-medium"
                      aria-label="Featured project"
                    />
                  )}
                </div>
                <span className="shrink-0 font-mono text-[0.7rem] text-slate tabular-nums">
                  {project.year}
                </span>
              </div>

              <h3 className="relative font-display text-lg leading-snug font-semibold text-bone transition-colors duration-200 group-hover:text-matrix">
                {project.title}
              </h3>

              {project.severity && (
                <div className="relative mt-3">
                  <SeverityBadge level={project.severity} />
                </div>
              )}

              <p className="relative mt-3 text-[0.82rem] leading-relaxed text-ash">
                {project.summary}
              </p>

              {/* Outcome */}
              <p className="relative mt-4 flex items-start gap-2 border-l-2 border-matrix/40 pl-3 font-mono text-[0.72rem] leading-relaxed text-matrix-dim">
                {project.impact}
              </p>

              {/* Stack */}
              <ul className="relative mt-5 flex flex-wrap gap-1.5">
                {project.stack.map((item) => (
                  <li key={item}>
                    <Tag>{item}</Tag>
                  </li>
                ))}
              </ul>

              {/* Links */}
              {(project.repo || project.writeup) && (
                <div className="relative mt-auto flex flex-wrap items-center gap-4 border-t border-line pt-5">
                  {project.repo && (
                    <a
                      href={project.repo}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-11 items-center gap-1.5 font-mono text-xs text-ash transition-colors duration-200 hover:text-matrix"
                    >
                      <Github className="size-3.5" aria-hidden="true" />
                      Source
                      <span className="sr-only"> for {project.title}</span>
                      <ArrowUpRight className="size-3" aria-hidden="true" />
                    </a>
                  )}
                  {project.writeup && (
                    <a
                      href={project.writeup}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-11 items-center gap-1.5 font-mono text-xs text-ash transition-colors duration-200 hover:text-matrix"
                    >
                      <FileText className="size-3.5" aria-hidden="true" />
                      Writeup
                      <span className="sr-only"> for {project.title}</span>
                      <ArrowUpRight className="size-3" aria-hidden="true" />
                    </a>
                  )}
                </div>
              )}
            </motion.article>
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Filtered-zero state — actionable, not a dead end */}
      {visible.length === 0 && (
        <div className="glass clip-corner flex flex-col items-center gap-4 px-6 py-16 text-center">
          <FolderOpen className="size-7 text-slate" aria-hidden="true" />
          <div>
            <p className="font-display text-lg text-bone">
              Nothing published under “{filter}” yet
            </p>
            <p className="mt-1.5 font-mono text-xs text-slate">
              Work in this category is either in progress or still under
              embargo.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setFilter("All")}
            className="clip-corner-sm mt-1 inline-flex min-h-11 cursor-pointer items-center border border-matrix/50 bg-matrix/10 px-5 font-mono text-xs text-matrix transition-colors duration-200 hover:bg-matrix/20"
          >
            Show all projects
          </button>
        </div>
      )}
    </SectionShell>
  );
}
