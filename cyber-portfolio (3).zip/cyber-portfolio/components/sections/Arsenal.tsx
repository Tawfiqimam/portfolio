"use client";

import { useMemo } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Activity, Cpu, HardDrive, Wifi } from "lucide-react";
import { arsenal, type Tool } from "@/lib/site";
import SectionShell from "@/components/ui/SectionShell";
import Reveal from "@/components/ui/Reveal";
import { cn } from "@/lib/utils";
import { EASE_OUT_EXPO } from "@/lib/motion";

/* Custom tooling leads, because that is the differentiator. */
const order: Tool["category"][] = [
  "Custom",
  "Web",
  "Network",
  "Mobile",
  "Platform",
];

export default function Arsenal() {
  const reduce = useReducedMotion();

  const grouped = useMemo(
    () =>
      order
        .map((category) => ({
          category,
          tools: arsenal.filter((tool) => tool.category === category),
        }))
        .filter((group) => group.tools.length > 0),
    [],
  );

  const average = Math.round(
    arsenal.reduce((sum, tool) => sum + tool.mastery, 0) / arsenal.length,
  );

  return (
    <SectionShell
      id="arsenal"
      index="// 07"
      eyebrow="Arsenal"
      title={
        <>
          The <span className="text-matrix">toolkit</span>.
        </>
      }
      description="What actually gets opened during an engagement. Tools are a means — but knowing one deeply beats knowing twelve shallowly."
    >
      {/* Status strip */}
      <Reveal>
        <div className="glass clip-corner mb-8 grid grid-cols-2 gap-px overflow-hidden bg-line sm:grid-cols-4">
          {[
            { icon: HardDrive, label: "Tools tracked", value: String(arsenal.length) },
            { icon: Activity, label: "Mean proficiency", value: `${average}%` },
            { icon: Cpu, label: "Primary platform", value: "Kali Linux" },
            { icon: Wifi, label: "Self-built tools", value: "2" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="flex items-center gap-3 bg-abyss/90 px-4 py-4"
            >
              <stat.icon className="size-4 shrink-0 text-matrix" aria-hidden="true" />
              <div className="min-w-0">
                <p className="font-mono text-[0.6rem] tracking-[0.14em] text-slate uppercase">
                  {stat.label}
                </p>
                <p className="font-display text-sm font-semibold text-bone tabular-nums">
                  {stat.value}
                </p>
              </div>
            </div>
          ))}
        </div>
      </Reveal>

      {/* Dashboard */}
      <div className="space-y-8">
        {grouped.map((group, groupIndex) => (
          <Reveal key={group.category} delay={Math.min(groupIndex * 0.05, 0.2)}>
            <div>
              <div className="mb-3 flex items-center gap-3">
                <h3 className="font-mono text-[0.7rem] tracking-[0.2em] text-matrix uppercase">
                  {group.category}
                </h3>
                <span
                  aria-hidden="true"
                  className="h-px flex-1 bg-linear-to-r from-line-bright to-transparent"
                />
                <span className="font-mono text-[0.65rem] text-slate tabular-nums">
                  {String(group.tools.length).padStart(2, "0")}
                </span>
              </div>

              <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {group.tools.map((tool, i) => (
                  <li key={tool.name}>
                    <div
                      className={cn(
                        "group glass clip-corner-sm relative overflow-hidden p-4",
                        "transition-colors duration-300 hover:border-matrix/35",
                      )}
                    >
                      <div className="flex items-baseline justify-between gap-3">
                        <p className="truncate font-mono text-sm font-medium text-bone transition-colors duration-200 group-hover:text-matrix">
                          {tool.name}
                        </p>
                        <p className="shrink-0 font-mono text-[0.7rem] text-matrix tabular-nums">
                          {tool.mastery}
                          <span className="text-slate">%</span>
                        </p>
                      </div>

                      <p className="mt-1.5 truncate font-mono text-[0.68rem] text-slate">
                        {tool.use}
                      </p>

                      {/* Segmented proficiency bar — 20 ticks, so the level is
                          readable as a count and not only as a length. */}
                      <div
                        role="progressbar"
                        aria-label={`${tool.name} proficiency`}
                        aria-valuenow={tool.mastery}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        className="mt-3 flex gap-[3px]"
                      >
                        {Array.from({ length: 20 }, (_, tick) => {
                          const filled = tick < Math.round(tool.mastery / 5);
                          return (
                            <motion.span
                              key={tick}
                              className={cn(
                                "h-2.5 flex-1 origin-bottom",
                                filled ? "bg-matrix/80" : "bg-surface-3",
                              )}
                              initial={
                                reduce ? { scaleY: 1 } : { scaleY: 0.25, opacity: 0.4 }
                              }
                              whileInView={{ scaleY: 1, opacity: 1 }}
                              viewport={{ once: true, margin: "-40px" }}
                              transition={
                                reduce
                                  ? { duration: 0 }
                                  : {
                                      duration: 0.3,
                                      delay: i * 0.04 + tick * 0.012,
                                      ease: EASE_OUT_EXPO,
                                    }
                              }
                            />
                          );
                        })}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </div>
    </SectionShell>
  );
}
