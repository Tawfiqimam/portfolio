import Link from "next/link";
import { Terminal } from "lucide-react";

export const metadata = { title: "404 — Route Not Found" };

export default function NotFound() {
  return (
    <section className="mx-auto flex min-h-dvh max-w-2xl flex-col items-center justify-center gap-6 px-6 text-center">
      <p className="eyebrow">Error 404</p>
      <h1 className="text-4xl sm:text-5xl">
        Route not found<span className="text-matrix">.</span>
      </h1>
      <div className="glass clip-corner w-full p-5 text-left font-mono text-sm">
        <p className="text-ash">
          <span className="text-matrix">$</span> curl -I {"<requested-path>"}
        </p>
        <p className="mt-2 text-critical">HTTP/2 404</p>
        <p className="text-slate">
          This endpoint does not exist, or is not exposed publicly.
        </p>
      </div>
      <Link
        href="/"
        className="clip-corner inline-flex min-h-11 cursor-pointer items-center gap-2 border border-matrix/50 bg-matrix/10 px-5 text-sm font-medium text-matrix transition-colors duration-200 hover:bg-matrix/20"
      >
        <Terminal className="size-4" aria-hidden="true" />
        Return to root
      </Link>
    </section>
  );
}
