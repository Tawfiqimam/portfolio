import type { Metadata, Viewport } from "next";
import { JetBrains_Mono, Space_Grotesk } from "next/font/google";
import { site } from "@/lib/site";
import Preloader from "@/components/layout/Preloader";
import CustomCursor from "@/components/layout/CustomCursor";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import AmbientFx from "@/components/layout/AmbientFx";
import "./globals.css";

/* Self-hosted at build time by next/font — no external request, no layout
   shift, and both are variable fonts so the weight range costs one file. */
const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-jetbrains",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-space-grotesk",
});

const title = `${site.name} — ${site.roles.join(" | ")}`;

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: title,
    template: `%s — ${site.name}`,
  },
  description: site.description,
  applicationName: `${site.name} // Security Research`,
  authors: [{ name: site.name, url: site.url }],
  creator: site.name,
  keywords: [
    "cybersecurity researcher",
    "penetration tester",
    "ethical hacker",
    "red team operator",
    "web application security",
    "vulnerability research",
    "OSINT",
    "CVE research",
    "responsible disclosure",
    "security consultant",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    url: site.url,
    siteName: site.name,
    title,
    description: site.description,
    images: [
      {
        url: "/opengraph-image.png",
        width: 1200,
        height: 630,
        alt: `${site.name} — ${site.role}`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title,
    description: site.description,
    images: ["/opengraph-image.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  category: "technology",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  /* Zoom is never disabled, and maximumScale is left unset so pinch-zoom
     works. Only the UI chrome colour is pinned. */
  themeColor: "#050505",
  colorScheme: "dark",
};

/* Structured data. Person + the work, so search engines understand this is a
   professional profile rather than a product page. */
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: site.name,
  url: site.url,
  email: `mailto:${site.email}`,
  jobTitle: site.roles.join(", "),
  description: site.description,
  knowsAbout: [
    "Penetration Testing",
    "Web Application Security",
    "Network Security",
    "Vulnerability Assessment",
    "Open-Source Intelligence",
    "Red Teaming",
    "Linux",
    "Python",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${jetbrains.variable} ${spaceGrotesk.variable} dark`}
      suppressHydrationWarning
    >
      <body className="relative min-h-dvh bg-void text-bone antialiased">
        <script
          type="application/ld+json"
          // Static, author-controlled object — not user input.
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        {/* First tab stop on the page. */}
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[200] focus:border focus:border-matrix focus:bg-void focus:px-4 focus:py-2 focus:font-mono focus:text-sm focus:text-matrix"
        >
          Skip to main content
        </a>

        {/* Scroll reveals and the preloader are JS-driven. Without JS the
            revealed content would never un-hide, so force it visible. */}
        <noscript>
          <style>{`
            [data-reveal] { opacity: 1 !important; transform: none !important; }
          `}</style>
        </noscript>

        <Preloader />
        <AmbientFx />
        <CustomCursor />
        <Navbar />

        <main id="main" className="relative z-10">
          {children}
        </main>

        <Footer />
      </body>
    </html>
  );
}
