import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Skills from "@/components/sections/Skills";
import Projects from "@/components/sections/Projects";
import Research from "@/components/sections/Research";
import Education from "@/components/sections/Education";
import Experience from "@/components/sections/Experience";
import Arsenal from "@/components/sections/Arsenal";
import Contact from "@/components/sections/Contact";

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Skills />
      <Research />
      <Projects />
      <Education />
      <Experience />
      <Arsenal />
      <Contact />
    </>
  );
}
